# 🚀 Guide de Déploiement CAKENEWS

Ce guide explique comment déployer l'application CAKENEWS sur différentes plateformes.

## 📋 Table des Matières

1. [Prérequis](#prérequis)
2. [Configuration GitHub](#configuration-github)
3. [Déploiement sur Vercel](#déploiement-sur-vercel)
4. [Déploiement sur Netlify](#déploiement-sur-netlify)
5. [Configuration Supabase Edge Functions](#configuration-supabase-edge-functions)
6. [Variables d'Environnement](#variables-denvironnement)
7. [Vérifications Post-Déploiement](#vérifications-post-déploiement)

## ✅ Prérequis

- Compte GitHub (déjà configuré sur Replit)
- Compte Supabase avec projet configuré
- Compte Vercel ou Netlify (pour l'hébergement)
- Supabase CLI installé (`npm install -g supabase`)

## 📦 Configuration GitHub

### Pousser le Code vers GitHub

Le projet est déjà connecté à GitHub via Replit. Pour pousser vos changements :

1. **Via l'interface Replit** (recommandé)
   - Utilisez l'onglet "Version Control" dans Replit
   - Commitez et poussez vos changements

2. **Via la ligne de commande**
```bash
git add .
git commit -m "feat: initial deployment setup"
git push origin main
```

## 🌐 Déploiement sur Vercel

### Méthode Automatique (Recommandée)

1. **Connecter GitHub à Vercel**
   - Aller sur [vercel.com](https://vercel.com)
   - Cliquer sur "Add New Project"
   - Importer votre repository GitHub

2. **Configuration du Build**
   ```
   Framework Preset: Vite
   Build Command: npm run build
   Output Directory: dist
   Install Command: npm install
   ```

3. **Ajouter les Variables d'Environnement**
   ```
   VITE_SUPABASE_URL=https://your-project.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-key
   ```

4. **Déployer**
   - Cliquer sur "Deploy"
   - Vercel va build et déployer automatiquement

### Méthode CLI

```bash
# Installer Vercel CLI
npm install -g vercel

# Se connecter
vercel login

# Déployer
vercel --prod

# Configurer les variables d'environnement
vercel env add VITE_SUPABASE_URL
vercel env add VITE_SUPABASE_ANON_KEY
```

## 📡 Déploiement sur Netlify

### Via l'Interface Web

1. **Connecter le Repository**
   - Aller sur [netlify.com](https://netlify.com)
   - "Add new site" → "Import an existing project"
   - Sélectionner GitHub et votre repository

2. **Configuration du Build**
   ```
   Build command: npm run build
   Publish directory: dist
   ```

3. **Variables d'Environnement**
   - Aller dans "Site settings" → "Environment variables"
   - Ajouter :
     ```
     VITE_SUPABASE_URL
     VITE_SUPABASE_ANON_KEY
     ```

4. **Déployer**
   - Netlify va automatiquement déployer

### Via Netlify CLI

```bash
# Installer Netlify CLI
npm install -g netlify-cli

# Se connecter
netlify login

# Initialiser
netlify init

# Déployer
netlify deploy --prod
```

## ⚡ Configuration Supabase Edge Functions

Les Edge Functions nécessitent un déploiement séparé sur Supabase.

### Déployer les Edge Functions

```bash
# 1. Lier votre projet Supabase
supabase link --project-ref your-project-ref

# 2. Déployer toutes les fonctions
supabase functions deploy track-view
supabase functions deploy notify-new-article
supabase functions deploy publish-scheduled-articles
supabase functions deploy increment-scheduled-view
supabase functions deploy update-admin-password

# 3. Configurer les secrets
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
```

### Tester les Edge Functions

```bash
# Tester localement
supabase functions serve track-view

# Tester en production
curl -i --location --request POST 'https://your-project.supabase.co/functions/v1/track-view' \
  --header 'Authorization: Bearer YOUR_ANON_KEY' \
  --header 'Content-Type: application/json' \
  --data '{"articleId":"test-id"}'
```

## 🔐 Variables d'Environnement

### Variables Requises

| Variable | Description | Où l'obtenir |
|----------|-------------|--------------|
| `VITE_SUPABASE_URL` | URL du projet Supabase | Supabase Dashboard → Settings → API |
| `VITE_SUPABASE_ANON_KEY` | Clé publique Supabase | Supabase Dashboard → Settings → API |

### Variables Optionnelles (Edge Functions)

| Variable | Description |
|----------|-------------|
| `SUPABASE_SERVICE_ROLE_KEY` | Clé admin pour Edge Functions |

### Configuration sur différentes plateformes

**Vercel**
```bash
vercel env add VITE_SUPABASE_URL production
vercel env add VITE_SUPABASE_ANON_KEY production
```

**Netlify**
```bash
netlify env:set VITE_SUPABASE_URL "your-url"
netlify env:set VITE_SUPABASE_ANON_KEY "your-key"
```

**Replit** (déjà configuré)
- Utiliser l'onglet "Secrets" dans Replit

## ✅ Vérifications Post-Déploiement

### Checklist

- [ ] Site accessible via l'URL de production
- [ ] Authentification fonctionne (login/signup)
- [ ] Articles s'affichent correctement
- [ ] Dashboard admin accessible (avec compte admin)
- [ ] Upload d'images fonctionne
- [ ] Commentaires s'enregistrent
- [ ] Notifications en temps réel fonctionnent
- [ ] Publication programmée active (vérifier Supabase Cron)

### Tests de Base

1. **Test Authentification**
   - Créer un compte
   - Se connecter
   - Se déconnecter

2. **Test Lecture**
   - Afficher la page d'accueil
   - Lire un article
   - Vérifier les images

3. **Test Admin** (avec compte admin)
   - Accéder au dashboard
   - Créer un article
   - Uploader une image
   - Publier l'article

4. **Test Interactions**
   - Liker un article
   - Commenter un article
   - Vérifier les notifications

### Outils de Monitoring

**Supabase Dashboard**
- Vérifier les logs d'authentification
- Monitorer l'utilisation de la base de données
- Vérifier les Edge Functions logs

**Vercel/Netlify Analytics**
- Vérifier les temps de réponse
- Monitorer les erreurs 404/500
- Analyser le trafic

## 🔄 Mises à Jour et CI/CD

### Déploiement Automatique

**Vercel** - Déploiement automatique sur chaque push
```
main branch → Production
feature/* branches → Preview deployments
```

**Netlify** - Même comportement
```
main → Production
Pull Requests → Deploy Previews
```

### Workflow Git Recommandé

```bash
# 1. Créer une branche feature
git checkout -b feature/new-feature

# 2. Développer et commiter
git add .
git commit -m "feat: add new feature"

# 3. Pousser et créer une PR
git push origin feature/new-feature

# 4. Merger après review
# → Déploiement automatique en production
```

## 🐛 Dépannage

### Build Échoue

**Erreur**: `Module not found`
```bash
# Solution: Vérifier package.json et réinstaller
npm install
```

**Erreur**: `Environment variable not found`
```bash
# Solution: Vérifier les variables d'environnement
# sur la plateforme de déploiement
```

### Edge Functions ne fonctionnent pas

```bash
# 1. Vérifier le déploiement
supabase functions list

# 2. Voir les logs
supabase functions logs track-view

# 3. Redéployer si nécessaire
supabase functions deploy track-view --no-verify-jwt
```

### Images ne s'affichent pas

1. Vérifier les policies Storage dans Supabase
2. Vérifier les CORS settings
3. Vérifier les URLs publiques

## 📊 Performance

### Optimisations Recommandées

1. **Compression d'Images** (déjà implémentée)
   - Format carré : 1080x1080px
   - Format vertical : 1080x1920px

2. **Caching**
   - Activer le cache CDN sur Vercel/Netlify
   - Cache-Control headers déjà configurés

3. **Code Splitting**
   - Routes lazy-loadées automatiquement par Vite

4. **Database Indexing**
   - Index déjà créés dans les migrations

## 🔒 Sécurité

### Avant Production

- [ ] Vérifier toutes les RLS policies Supabase
- [ ] Activer Rate Limiting sur les Edge Functions
- [ ] Configurer CORS correctement
- [ ] Vérifier les permissions Storage
- [ ] Activer HTTPS (automatique sur Vercel/Netlify)
- [ ] Configurer CSP headers (optionnel)

### Supabase Row Level Security

Toutes les tables ont RLS activé. Vérifier dans Supabase Dashboard :
```sql
-- Exemple de policy
CREATE POLICY "Users can read published articles"
ON articles FOR SELECT
USING (published = true);
```

## 📞 Support

En cas de problème :
1. Vérifier les logs de déploiement
2. Consulter la documentation Supabase
3. Vérifier les GitHub Issues du projet
4. Contacter l'équipe de développement

---

**Dernière mise à jour**: Novembre 2025  
**Maintenu par**: CAKENEWS Team
