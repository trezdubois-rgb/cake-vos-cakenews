# 🚀 Pousser CAKENEWS vers GitHub

## ⚡ Méthode Rapide (Recommandée)

### Utiliser le script automatisé

```bash
./deploy-to-github.sh
```

Le script va :
1. Vérifier votre configuration Git
2. Afficher les fichiers modifiés
3. Demander confirmation
4. Créer un commit
5. Pousser vers GitHub

## 🔧 Méthode Manuelle

### 1. Configurer Git (première fois uniquement)

```bash
git config user.name "Votre Nom"
git config user.email "votre@email.com"
```

### 2. Vérifier le repository distant

```bash
git remote -v
```

Si aucun remote n'est configuré :
```bash
git remote add origin https://github.com/votre-username/cakenews.git
```

### 3. Pousser le code

```bash
# Ajouter tous les fichiers
git add .

# Créer un commit
git commit -m "feat: initial deployment of CAKENEWS platform"

# Pousser vers GitHub
git push origin main
```

Si vous avez une erreur "main" vs "master" :
```bash
git push origin master
```

## 📦 Ce qui sera poussé

### Fichiers Inclus
✅ Code source complet (`src/`)  
✅ Configuration Vite et TypeScript  
✅ Composants UI Shadcn  
✅ Pages admin et publiques  
✅ Migrations Supabase  
✅ Edge Functions Supabase  
✅ Documentation (README.md, DEPLOYMENT.md)  
✅ Configuration package.json  

### Fichiers Exclus (.gitignore)
❌ `node_modules/` - Dépendances (sera réinstallé)  
❌ `dist/` - Build (sera regénéré)  
❌ `.env` - Variables d'environnement (secrets)  
❌ `.replit` - Configuration Replit  
❌ Fichiers temporaires et logs  

## 🔐 Sécurité

### ⚠️ IMPORTANT : Ne jamais commiter

- ❌ Clés API Supabase
- ❌ Mots de passe
- ❌ Tokens d'authentification
- ❌ Fichiers `.env`

Toutes les variables sensibles sont déjà dans `.gitignore`.

## ✅ Vérification Post-Push

Après avoir poussé vers GitHub :

1. **Vérifier sur GitHub.com**
   - Aller sur votre repository
   - Vérifier que tous les fichiers sont présents
   - Vérifier que `.env` n'est PAS présent

2. **Vérifier le README**
   - Le README.md devrait s'afficher correctement
   - Toutes les instructions sont claires

3. **Branches**
   - Branch principal : `main` ou `master`
   - Créer des branches feature si besoin

## 🎯 Prochaines Étapes

Après avoir poussé vers GitHub :

### 1. Déployer sur Vercel
```bash
# Installer Vercel CLI
npm install -g vercel

# Déployer
vercel --prod
```

### 2. Configurer les Variables d'Environnement
Dans Vercel Dashboard :
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

### 3. Déployer les Edge Functions
```bash
supabase functions deploy track-view
supabase functions deploy notify-new-article
supabase functions deploy publish-scheduled-articles
```

### 4. Tester le Déploiement
- [ ] Site accessible
- [ ] Authentification fonctionne
- [ ] Articles s'affichent
- [ ] Dashboard admin accessible

## 🐛 Dépannage

### Erreur : "Permission denied"
```bash
chmod +x deploy-to-github.sh
./deploy-to-github.sh
```

### Erreur : "remote: Permission to ... denied"
→ Vérifier que vous êtes connecté à GitHub sur Replit  
→ Utiliser l'interface Replit "Version Control"

### Erreur : "nothing to commit"
→ Normal, aucun changement depuis le dernier commit  
→ Modifier des fichiers puis réessayer

### Erreur : "failed to push"
→ Faire un `git pull` d'abord  
→ Résoudre les conflits  
→ Puis `git push`

## 📖 Documentation Complète

Consultez :
- `README.md` - Documentation générale
- `DEPLOYMENT.md` - Guide de déploiement complet

## 💡 Tips

### Workflow Git Recommandé

```bash
# 1. Créer une branche pour une nouvelle feature
git checkout -b feature/nom-feature

# 2. Développer et tester
# ... vos modifications ...

# 3. Commiter régulièrement
git add .
git commit -m "feat: description de la feature"

# 4. Pousser la branche
git push origin feature/nom-feature

# 5. Créer une Pull Request sur GitHub

# 6. Merger dans main après review
```

### Messages de Commit Conventionnels

```bash
feat: nouvelle fonctionnalité
fix: correction de bug
docs: mise à jour documentation
style: formatage, pas de changement de code
refactor: refactoring du code
test: ajout de tests
chore: maintenance, dépendances
```

Exemples :
```bash
git commit -m "feat: add article scheduling feature"
git commit -m "fix: resolve image upload issue"
git commit -m "docs: update README with deployment steps"
```

## 🎉 Succès !

Une fois poussé vers GitHub, votre code est :
- ✅ Sauvegardé en ligne
- ✅ Versionné
- ✅ Prêt pour le déploiement
- ✅ Partageable avec l'équipe

---

**Besoin d'aide ?** Consultez [GitHub Docs](https://docs.github.com)
