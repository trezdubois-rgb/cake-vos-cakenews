# CAKENEWS Platform

## Overview

CAKENEWS is a modern, mobile-first news publishing platform that delivers an immersive article reading experience through swipe-based navigation. The platform features a comprehensive admin dashboard for content management, a rich text editor for article creation, and real-time user engagement through comments, likes, and notifications. Built with React, TypeScript, and Supabase, it provides both public access (with guest mode restrictions) and authenticated user features.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18 with TypeScript** - Component-based UI with static typing for better developer experience and code quality
- **Vite** - Modern build tool chosen for its lightning-fast hot module replacement and optimized production builds
- **Single Page Application (SPA)** - Client-side routing with React Router v6 for seamless navigation without page reloads

**UI Design System**
- **TailwindCSS** - Utility-first CSS framework for rapid UI development with consistent design tokens
- **Shadcn/UI Components** - Pre-built, accessible component library built on Radix UI primitives
- **Mobile-First Design** - Layout optimized for portrait mobile viewing with swipe gestures, falling back gracefully to desktop
- **Dark/Light Theme Support** - Theme switching capability with localStorage persistence

**State Management**
- **TanStack Query (React Query)** - Server state management with automatic caching, refetching, and synchronization
- **React Hooks** - Local component state management using useState, useEffect, and custom hooks
- **Context API** - Authentication state shared globally through useAuth hook

**Key Features Architecture**
- **Swipe Navigation** - Custom `useSwipeGesture` hook detects horizontal swipes for article navigation, with edge protection to avoid conflicts with browser gestures
- **Guest Mode System** - Time-limited (40 seconds) access for non-authenticated users with session tracking via localStorage and Supabase `guest_sessions` table
- **Real-time Subscriptions** - Supabase Realtime for live notifications and comment updates
- **Image Compression** - Client-side image optimization using browser-image-compression before upload to reduce storage costs

### Backend Architecture

**Backend as a Service (Supabase)**
- **PostgreSQL Database** - Relational database for structured data storage
- **Row Level Security (RLS)** - Database-level access control policies ensure users can only access authorized data
- **Supabase Auth** - Built-in authentication supporting email/password with customizable user metadata
- **Supabase Storage** - Object storage for media files (images, videos, audio) with public/private bucket support
- **Edge Functions (Deno)** - Serverless functions for server-side logic like view tracking (`track-view` function)

**Database Schema Design**
- **articles** - Main content table with fields for title, content_html (TipTap output), hero images/videos, categories, tags, and engagement metrics
- **profiles** - Extended user data including display_name, avatar_url, and preferences (JSON field for personalization settings)
- **user_roles** - Role-based access control mapping users to roles (admin, user)
- **comments** - Nested comment system with parent_id for threading
- **article_likes** - User-article like relationships
- **notifications** - User notification queue with read/unread status
- **media_library** - Centralized media asset management
- **categories** - Article categorization taxonomy
- **guest_sessions** - Tracking for unauthenticated user sessions with time limits and blocking

**Authentication Flow**
- User signs up → Supabase creates auth.users record + triggers profile creation
- Login generates JWT token stored in browser
- Protected routes check authentication via `ProtectedRoute` component
- Admin routes additionally verify role via `user_roles` table

### Rich Text Editor

**TipTap Block Editor**
- **Extension-based Architecture** - TipTap provides a modular editor built on ProseMirror
- **Supported Content Types**:
  - Text formatting (bold, italic, headings, alignment, color, highlight)
  - Embedded media (images, YouTube videos, custom audio extension)
  - Lists (ordered/unordered)
  - Links and code blocks
- **Content Storage** - All content serialized to HTML and stored in `content_html` field (deprecated block-based JSON format for simpler rendering)
- **Custom Extensions** - Audio extension created for native audio player embedding

### Engagement & Personalization

**User Interaction Tracking**
- **View Tracking** - Edge function increments view_count when user spends >1 second on article
- **Like System** - Toggle likes with optimistic UI updates, persisted to article_likes table
- **Comment System** - Nested comments with emoji reactions, stored in comments table with parent_id relationships
- **Favorites** - User can bookmark articles for later (stored in user preferences)

**Content Personalization**
- **Preference System** - Users define preferences for tags, authors, categories stored as JSON in profiles table
- **Feed Filtering** - "Mon Flux" (My Feed) scores and filters articles based on user preference weights
- **Hide/Block Features** - Users can hide specific articles, authors, categories, or tags from their feed

### Guest Mode System

**Design Rationale**
- Provides limited access to encourage sign-ups while allowing content discovery
- 40-second time limit creates urgency without being overly restrictive
- 24-hour block after session expires prevents abuse while remaining user-friendly

**Technical Implementation**
- `useGuestMode` hook manages session state and countdown timer
- `GuestBlocker` component redirects to auth when time expires
- Session ID stored in localStorage, tracked in `guest_sessions` table with timestamps
- `GuestTimer` displays countdown badge when <60 seconds remain
- `GuestPromptDialog` appears when blocked, requires account creation to continue

### Admin Dashboard

**Multi-Section Architecture**
- **Articles Management** - CRUD operations, draft/published status, scheduled publishing
- **Media Library** - Centralized asset browser with upload, compression, and organization
- **Categories Manager** - Hierarchical category organization
- **Users Manager** - User role assignment, profile management
- **Ads Manager** - Advertising content management (square images, vertical videos)
- **Design Manager** - Theme customization and branding settings
- **Settings** - Application-wide configuration

**Admin Routing**
- Separate `AdminBottomNav` for admin-specific navigation
- All `/admin/*` routes protected by `requireAdmin` prop on ProtectedRoute
- Admin status checked via user_roles table query

## External Dependencies

### Core Services

**Supabase**
- **Purpose** - Complete backend infrastructure (database, auth, storage, realtime, edge functions)
- **Database** - PostgreSQL with Row Level Security for multi-tenant data isolation
- **Authentication** - JWT-based auth with email/password support
- **Storage** - Object storage for user-uploaded media with CDN delivery
- **Realtime** - WebSocket subscriptions for live notifications and comments
- **Edge Functions** - Deno-based serverless functions deployed at the edge

### Third-Party Packages

**UI & Styling**
- `@radix-ui/*` - Unstyled, accessible component primitives (dialogs, dropdowns, tooltips, etc.)
- `tailwindcss` - Utility-first CSS framework
- `class-variance-authority` - Type-safe variant management for components
- `lucide-react` - Icon library

**Rich Text Editing**
- `@tiptap/react` - Headless editor framework
- `@tiptap/starter-kit` - Essential editor extensions
- `@tiptap/extension-*` - Additional extensions (image, link, youtube, color, highlight, text-align)

**Data Management**
- `@tanstack/react-query` - Async state management with caching
- `@supabase/supabase-js` - Supabase JavaScript client

**Forms & Validation**
- `react-hook-form` - Performant form state management
- `@hookform/resolvers` - Validation schema resolvers
- `zod` - TypeScript-first schema validation

**Utilities**
- `browser-image-compression` - Client-side image optimization
- `date-fns` - Date manipulation and formatting
- `sonner` - Toast notification system
- `vaul` - Drawer/bottom sheet component

**Development**
- `vite` - Build tool and dev server
- `typescript` - Static type checking
- `eslint` - Code linting
- `@vitejs/plugin-react-swc` - Fast React refresh with SWC compiler

### API Integrations

**GitHub API (Optional)**
- `@octokit/rest` - GitHub REST API client included in dependencies (likely for deployment automation)

**Media Delivery**
- Supabase Storage serves as CDN for all media assets
- Hero images and videos loaded directly from storage buckets with public URLs

### Build & Deployment

**Target Platforms**
- Vercel (recommended) - Automatic deployments from Git with serverless functions support
- Netlify (alternative) - Similar static hosting with edge functions

**Environment Variables Required**
- `VITE_SUPABASE_URL` - Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Supabase anonymous/public API key