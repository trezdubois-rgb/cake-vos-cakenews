#!/bin/bash

# CAKENEWS - Script de Déploiement GitHub
# Ce script automatise le push du code vers GitHub

set -e

echo "🍰 CAKENEWS - Déploiement GitHub"
echo "================================"

# Vérifier si git est configuré
if ! git config user.name > /dev/null 2>&1; then
    echo "⚠️  Configuration Git manquante"
    echo "Veuillez configurer Git avec:"
    echo "  git config user.name 'Votre Nom'"
    echo "  git config user.email 'votre@email.com'"
    exit 1
fi

# Afficher le statut actuel
echo ""
echo "📊 Statut du repository:"
git status --short

# Demander confirmation
echo ""
read -p "Voulez-vous continuer avec le commit et push ? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Annulé"
    exit 0
fi

# Demander le message de commit
echo ""
read -p "Message de commit (ou Entrée pour message par défaut): " commit_message
if [ -z "$commit_message" ]; then
    commit_message="feat: deploy CAKENEWS to GitHub"
fi

# Ajouter tous les fichiers
echo ""
echo "📦 Ajout des fichiers..."
git add .

# Créer le commit
echo "💾 Création du commit..."
git commit -m "$commit_message" || {
    echo "⚠️  Aucun changement à commiter"
    exit 0
}

# Pousser vers GitHub
echo "🚀 Push vers GitHub..."
git push origin main || git push origin master || {
    echo "❌ Erreur lors du push"
    echo "Vérifiez votre connexion GitHub et réessayez"
    exit 1
}

echo ""
echo "✅ Déploiement réussi !"
echo ""
echo "📝 Prochaines étapes:"
echo "  1. Configurer le déploiement sur Vercel/Netlify"
echo "  2. Ajouter les variables d'environnement"
echo "  3. Déployer les Edge Functions Supabase"
echo ""
echo "📖 Consultez DEPLOYMENT.md pour les instructions complètes"
