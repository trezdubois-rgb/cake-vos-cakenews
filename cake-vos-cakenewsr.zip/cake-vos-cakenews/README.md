# 🍰 CAKENEWS - Plateforme de Publication d'Articles

Plateforme moderne de publication et gestion d'articles avec un dashboard administrateur complet, développée avec React, TypeScript et Supabase.

## ✨ Fonctionnalités

### 👥 Pour les Utilisateurs
- **Interface Mobile-First** - Navigation intuitive avec swipe gestures
- **Fil d'Actualités Personnalisé** - Articles recommandés basés sur les préférences
- **Système de Commentaires** - Interactions avec réactions emoji et threading
- **Likes & Favoris** - Sauvegarder et aimer les articles
- **Mode Invité** - Accès temporaire de 4 minutes pour les visiteurs
- **Notifications en Temps Réel** - Alertes pour nouveaux articles et interactions

### 🔐 Pour les Administrateurs
- **Éditeur d'Articles Riche** - TipTap avec support images, vidéos, audio
- **Gestion de Catégories** - Organisation hiérarchique du contenu
- **Bibliothèque de Médias** - Upload et compression automatique d'images
- **Gestionnaire de Publicités** - Support images carrées et vidéos verticales
- **Gestion d'Utilisateurs** - Attribution de rôles et permissions
- **Publication Programmée** - Planification automatique des articles
- **Statistiques Détaillées** - Vues, likes, engagement

## 🚀 Stack Technique

### Frontend
- **React 18** + **TypeScript** - Framework moderne avec typage statique
- **Vite** - Build tool ultra-rapide
- **TailwindCSS** + **Shadcn/UI** - Design system moderne
- **TanStack Query** - Gestion d'état serveur
- **React Router v6** - Navigation SPA
- **TipTap** - Éditeur WYSIWYG extensible

### Backend
- **Supabase** - Backend as a Service
  - **PostgreSQL** - Base de données relationnelle
  - **Row Level Security** - Sécurité au niveau ligne
  - **Storage** - Stockage de fichiers sécurisé
  - **Auth** - Authentification complète
  - **Realtime** - Subscriptions temps réel
  - **Edge Functions** - Serverless Deno

## 📦 Installation

### Prérequis
- Node.js 20+
- Compte Supabase
- Git

### Configuration Rapide

```bash
# 1. Cloner le projet
git clone <YOUR_REPO_URL>
cd cakenews

# 2. Installer les dépendances
npm install

# 3. Configurer les variables d'environnement
# Créer .env avec:
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# 4. Démarrer le serveur de développement
npm run dev
```

### Configuration Supabase

1. **Créer un projet Supabase** sur [supabase.com](https://supabase.com)

2. **Appliquer les migrations**
```bash
# Installer Supabase CLI
npm install -g supabase

# Lier le projet
supabase link --project-ref your-project-id

# Pousser les migrations
supabase db push
```

3. **Créer un admin**
```sql
-- Dans Supabase SQL Editor
INSERT INTO public.user_roles (user_id, role)
VALUES ('your-user-uuid', 'admin');
```

## 🗂️ Structure du Projet

```
cakenews/
├── src/
│   ├── components/          # Composants React
│   │   ├── article/         # Article, commentaires
│   │   ├── auth/            # Authentification
│   │   ├── editor/          # Éditeur TipTap
│   │   ├── feed/            # Fil d'actualités
│   │   └── ui/              # Composants Shadcn
│   ├── pages/               # Pages principales
│   │   └── admin/           # Dashboard admin
│   ├── hooks/               # Custom hooks
│   ├── lib/                 # Utilitaires
│   └── integrations/        # Supabase client
├── supabase/
│   ├── functions/           # Edge Functions
│   └── migrations/          # Migrations SQL
├── public/                  # Assets statiques
└── package.json
```

## 🎯 Modules Admin

| Module | Description |
|--------|-------------|
| **Dashboard** | Vue d'ensemble et statistiques |
| **Articles** | Créer, éditer, publier des articles |
| **Catégories** | Gérer l'arborescence des catégories |
| **Médias** | Bibliothèque centralisée de médias |
| **Publicités** | Gestion des pubs (images/vidéos) |
| **Utilisateurs** | Attribution de rôles et permissions |
| **Design** | Personnalisation des thèmes |
| **Paramètres** | Configuration du compte |

## 🔐 Système d'Authentification

### Rôles Disponibles
- **admin** - Accès complet au dashboard
- **user** - Lecture, commentaires, likes

### Routes Protégées
Toutes les routes `/admin/*` nécessitent le rôle `admin`.

## 📊 Modèle de Données

### Tables Principales

**profiles** - Profils utilisateurs
- Informations personnelles
- Préférences de contenu (tags, catégories, auteurs favoris)
- Avatar

**articles** - Contenu principal
- Support article, vidéo, audio (podcast)
- SEO (title, description)
- Publication programmée
- Statut (draft, scheduled, published, archived)
- Statistiques (vues, likes)

**categories** - Organisation du contenu
- Hiérarchie parent/enfant
- Couleur et icône personnalisées
- Ordre d'affichage

**comments** - Interactions utilisateurs
- Threading (réponses)
- Réactions emoji (👍 ❤️ 😂 😮 😢 🙏)
- Signalements
- Système de likes

**ads** - Publicités
- Placements configurables (après titre, milieu, fin)
- Support image carrée et vidéo verticale
- Statistiques (impressions, clics)
- Programmation (dates début/fin)

**media_library** - Médias centralisés
- Compression automatique
- Métadonnées (dimensions, durée, alt text)
- Support image, vidéo, document

## 🛠️ Scripts npm

```bash
npm run dev          # Serveur de développement (port 5000)
npm run build        # Build production
npm run preview      # Prévisualiser le build
npm run lint         # Vérifier le code
```

## 🚀 Déploiement

### Sur Replit
Le projet est pré-configuré :
- Port 5000 avec allowedHosts
- Workflow automatique
- Variables d'environnement via Secrets

### Sur Vercel/Netlify
```bash
npm run build
# Déployer le dossier dist/
```

Variables d'environnement requises :
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

## 🎨 Personnalisation

### Thèmes
Mode clair/sombre automatique via `next-themes`.

### Couleurs
Modifier `src/index.css` :
```css
:root {
  --primary: ...;
  --secondary: ...;
  /* etc. */
}
```

## 🔧 Fonctionnalités Avancées

### Compression d'Images
Automatique lors de l'upload :
- Format carré : 1080x1080px
- Format vertical : 1080x1920px
- Optimisation qualité/taille

### Vues Progressives
Système qui incrémente les vues graduellement sur 24h pour éviter les pics artificiels.

### Publication Programmée
Utilise Supabase Cron pour publier automatiquement les articles planifiés.

### Notifications Temps Réel
WebSocket via Supabase Realtime pour :
- Nouveaux articles
- Nouveaux commentaires
- Likes et interactions

## 🐛 Dépannage

**Erreur : "Could not find relationship"**
→ Vérifier que les migrations Supabase sont appliquées

**Images ne s'affichent pas**
→ Vérifier les policies Storage dans Supabase Dashboard

**Admin non reconnu**
→ Vérifier la présence dans `user_roles` table

## 📄 Technologies Utilisées

| Catégorie | Technologies |
|-----------|-------------|
| **Core** | React, TypeScript, Vite |
| **UI** | TailwindCSS, Shadcn/UI, Lucide Icons |
| **État** | TanStack Query, React Hook Form |
| **Backend** | Supabase (PostgreSQL, Auth, Storage) |
| **Éditeur** | TipTap (ProseMirror) |
| **Routing** | React Router v6 |
| **Forms** | React Hook Form + Zod |

## 📝 Licence

Propriétaire - Tous droits réservés

## 🤝 Contribution

Projet privé - Contributions sur invitation uniquement.

---

**Version**: 1.0.0  
**Dernière mise à jour**: Novembre 2025  
**Développé par**: CAKENEWS Team
