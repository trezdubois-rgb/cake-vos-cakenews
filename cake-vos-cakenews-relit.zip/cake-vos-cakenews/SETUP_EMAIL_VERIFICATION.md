# Configuration de la Vérification d'Email Supabase

Ce guide explique comment activer la vérification d'email pour votre projet Cake en production.

## ⚠️ IMPORTANT: Configuration Requise

L'application Cake est maintenant configurée pour **exiger la vérification d'email** avant d'accéder aux fonctionnalités protégées. Vous DEVEZ activer cette fonctionnalité dans votre dashboard Supabase pour que l'application fonctionne correctement en production.

## 📋 Étapes de Configuration

### 1. Accéder aux Paramètres d'Authentification

1. Connectez-vous à votre [Dashboard Supabase](https://app.supabase.com)
2. Sélectionnez votre projet
3. Dans le menu latéral, allez dans **Authentication** → **Providers**
4. Cliquez sur **Email**

### 2. Activer la Confirmation d'Email

1. Basculez l'option **"Confirm Email"** sur **ON**
2. Assurez-vous que **"Enable Signups"** est également activé
3. Cliquez sur **Save** pour enregistrer les modifications

### 3. Configurer les URLs de Redirection (Recommandé)

1. Allez dans **Authentication** → **URL Configuration**
2. Ajoutez vos URLs autorisées dans **Redirect URLs**:
   - Développement: `http://localhost:5000`
   - Production: `https://votre-domaine.com`
3. Sauvegardez les changements

### 4. Configurer SMTP pour la Production (OBLIGATOIRE)

Par défaut, Supabase limite l'envoi d'emails à **2/heure** avec le service email par défaut. Pour la production, vous DEVEZ configurer un service SMTP personnalisé.

#### Options SMTP Recommandées:

- **SendGrid** (recommandé) - 100 emails/jour gratuit
- **AWS SES** - Très économique à grande échelle
- **Mailgun** - 5000 emails/mois gratuit
- **Postmark** - Excellente délivrabilité

#### Configuration SMTP:

1. Dans le Dashboard Supabase, allez dans **Project Settings** → **Authentication**
2. Faites défiler jusqu'à **SMTP Settings**
3. Entrez vos informations SMTP:
   ```
   Host: smtp.votrefournisseur.com
   Port: 587 (ou 465 pour SSL)
   Username: votre-username
   Password: votre-mot-de-passe
   ```
4. Testez l'envoi avec le bouton **Send test email**

### 5. Personnaliser les Templates d'Email (Optionnel)

1. Allez dans **Authentication** → **Email Templates**
2. Personnalisez le template **Confirm signup**
3. Utilisez les variables disponibles:
   - `{{ .ConfirmationURL }}` - Lien de confirmation
   - `{{ .Token }}` - Code OTP à 6 chiffres
   - `{{ .SiteURL }}` - URL de votre application

Exemple de template personnalisé:
```html
<h2>Bienvenue sur Cake! 🎂</h2>
<p>Merci de vous être inscrit. Cliquez sur le bouton ci-dessous pour confirmer votre email:</p>
<p><a href="{{ .ConfirmationURL }}" style="padding: 12px 24px; background-color: #000; color: #fff; text-decoration: none; border-radius: 6px;">Confirmer mon email</a></p>
<p>Ou copiez ce lien dans votre navigateur:</p>
<p>{{ .ConfirmationURL }}</p>
```

## 🧪 Test en Développement Local

Si vous utilisez Supabase CLI en local:

1. Éditez `supabase/config.toml`:
```toml
[auth.email]
enable_confirmations = true
```

2. Les emails de test seront disponibles sur `http://localhost:54324` (InBucket)

## ✅ Vérification

Après configuration:

1. Créez un nouveau compte de test
2. Vérifiez que vous recevez l'email de confirmation
3. Cliquez sur le lien de vérification
4. Confirmez que vous pouvez accéder aux routes protégées

## 🔒 Sécurité

### Limite de Taux

- Service email par défaut: **2 nouveaux utilisateurs/heure**
- Avec SMTP personnalisé: **30 nouveaux utilisateurs/heure**

### Bonnes Pratiques

1. ✅ Toujours utiliser SMTP personnalisé en production
2. ✅ Configurer des alertes de monitoring pour les échecs d'envoi
3. ✅ Tester régulièrement le flow de vérification
4. ✅ Avoir une page de FAQ pour les utilisateurs qui ne reçoivent pas l'email

## 🛠️ Fonctionnalités Implémentées dans Cake

L'application inclut déjà:

- ✅ Blocage des routes protégées pour les emails non vérifiés
- ✅ Page de vérification avec possibilité de renvoyer l'email
- ✅ Messages d'erreur clairs
- ✅ Gestion automatique de la redirection après vérification
- ✅ Hook `useEmailVerification` pour vérifier l'état
- ✅ Composant `EmailVerificationPrompt` réutilisable

## 📚 Ressources

- [Documentation Supabase - Email Authentication](https://supabase.com/docs/guides/auth/passwords)
- [Email Templates Guide](https://supabase.com/docs/guides/auth/auth-email-templates)
- [SMTP Configuration](https://supabase.com/docs/guides/auth/auth-smtp)

## ⚠️ Note Importante

Sans activation de la confirmation d'email dans le dashboard:
- Les nouveaux utilisateurs pourront créer des comptes
- Mais ils seront **immédiatement redirigés** vers la page de vérification
- Et **ne pourront pas accéder** aux fonctionnalités de l'application
- Jusqu'à ce que la fonctionnalité soit activée dans Supabase

**Activez la confirmation d'email AVANT le déploiement en production!**
