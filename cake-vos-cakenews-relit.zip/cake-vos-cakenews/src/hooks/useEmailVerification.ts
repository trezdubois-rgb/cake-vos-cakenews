import { useAuth } from "./useAuth";

export function useEmailVerification() {
  const { user, loading } = useAuth();

  const isEmailVerified = user?.email_confirmed_at != null;
  const needsVerification = user != null && !isEmailVerified;

  return {
    isEmailVerified,
    needsVerification,
    loading,
    email: user?.email,
  };
}
