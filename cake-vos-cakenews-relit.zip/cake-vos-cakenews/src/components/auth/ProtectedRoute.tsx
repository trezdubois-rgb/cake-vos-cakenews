import { ReactNode, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useEmailVerification } from "@/hooks/useEmailVerification";
import { Skeleton } from "@/components/ui/skeleton";

interface ProtectedRouteProps {
  children: ReactNode;
  requireAdmin?: boolean;
  skipEmailVerification?: boolean;
}

export const ProtectedRoute = ({ 
  children, 
  requireAdmin = false,
  skipEmailVerification = false 
}: ProtectedRouteProps) => {
  const { user, loading, isAdmin } = useAuth();
  const { needsVerification } = useEmailVerification();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading) {
      if (!user) {
        navigate("/auth");
      } else if (!skipEmailVerification && needsVerification) {
        navigate("/verify-email");
      } else if (requireAdmin && !isAdmin) {
        navigate("/");
      }
    }
  }, [user, loading, isAdmin, requireAdmin, needsVerification, skipEmailVerification, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="space-y-4">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!user || (!skipEmailVerification && needsVerification) || (requireAdmin && !isAdmin)) {
    return null;
  }

  return <>{children}</>;
};
