import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, RefreshCw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

interface EmailVerificationPromptProps {
  email: string;
}

export function EmailVerificationPrompt({ email }: EmailVerificationPromptProps) {
  const [resending, setResending] = useState(false);
  const [resendEmail, setResendEmail] = useState("");
  const isGenericEmail = email === "votre adresse email";

  const handleResendEmail = async () => {
    const emailToUse = isGenericEmail ? resendEmail : email;
    
    if (!emailToUse || !emailToUse.includes('@')) {
      toast({
        title: "Email invalide",
        description: "Veuillez entrer une adresse email valide.",
        variant: "destructive",
      });
      return;
    }

    setResending(true);
    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: emailToUse,
      });

      if (error) throw error;

      toast({
        title: "Email envoyé !",
        description: "Vérifiez votre boîte de réception et vos spams.",
      });
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message || "Impossible de renvoyer l'email",
        variant: "destructive",
      });
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="max-w-md w-full">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Mail className="h-6 w-6 text-primary" data-testid="icon-email-verification" />
            <CardTitle data-testid="text-verification-title">Vérifiez votre email</CardTitle>
          </div>
          <CardDescription data-testid="text-verification-description">
            {!isGenericEmail ? (
              <>Un email de confirmation a été envoyé à <strong>{email}</strong></>
            ) : (
              <>Un email de confirmation vous a été envoyé. Vérifiez votre boîte de réception.</>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-muted p-4 rounded-md space-y-2">
            <p className="text-sm text-muted-foreground">
              Pour accéder à toutes les fonctionnalités de Cake, vous devez confirmer votre adresse email.
            </p>
            <ol className="text-sm text-muted-foreground list-decimal list-inside space-y-1 ml-2">
              <li>Ouvrez l'email de confirmation</li>
              <li>Cliquez sur le lien de vérification</li>
              <li>Vous serez automatiquement connecté</li>
            </ol>
          </div>

          {isGenericEmail && (
            <div className="space-y-2">
              <Label htmlFor="resend-email">Votre adresse email</Label>
              <Input
                id="resend-email"
                type="email"
                placeholder="email@exemple.com"
                value={resendEmail}
                onChange={(e) => setResendEmail(e.target.value)}
                data-testid="input-resend-email"
              />
            </div>
          )}

          <Button
            onClick={handleResendEmail}
            disabled={resending}
            className="w-full"
            variant="outline"
            data-testid="button-resend-email"
          >
            {resending ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Envoi en cours...
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-4 w-4" />
                Renvoyer l'email
              </>
            )}
          </Button>

          <p className="text-xs text-muted-foreground text-center">
            Vous n'avez pas reçu l'email ? Vérifiez vos spams ou renvoyez-le.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
