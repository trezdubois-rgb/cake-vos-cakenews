import { PostgrestError } from "@supabase/supabase-js";
import { toast } from "@/hooks/use-toast";

export interface ErrorHandlerOptions {
  showToast?: boolean;
  logError?: boolean;
  retryable?: boolean;
}

const DEFAULT_OPTIONS: ErrorHandlerOptions = {
  showToast: true,
  logError: true,
  retryable: false,
};

export function handleSupabaseError(
  error: PostgrestError | Error | null,
  context: string = "Opération",
  options: ErrorHandlerOptions = {}
): void {
  const opts = { ...DEFAULT_OPTIONS, ...options };

  if (!error) return;

  // Log l'erreur pour debugging
  if (opts.logError) {
    console.error(`[${context}]`, error);
  }

  // Déterminer le message utilisateur approprié
  let userMessage = "Une erreur est survenue";
  
  if ("code" in error && error.code) {
    switch (error.code) {
      case "PGRST116": // Not found
        userMessage = "Ressource introuvable";
        break;
      case "23505": // Unique violation
        userMessage = "Cette valeur existe déjà";
        break;
      case "23503": // Foreign key violation
        userMessage = "Opération impossible : données liées";
        break;
      case "42501": // Permission denied
        userMessage = "Vous n'avez pas les permissions nécessaires";
        break;
      case "42P01": // Table doesn't exist
        userMessage = "Erreur de configuration de la base de données";
        break;
      case "P0001": // Custom raised exception
        userMessage = error.message || "Opération refusée";
        break;
      default:
        userMessage = error.message || userMessage;
    }
  } else if ("message" in error) {
    userMessage = error.message;
  }

  // Afficher le toast si demandé
  if (opts.showToast) {
    toast({
      title: context,
      description: userMessage,
      variant: "destructive",
    });
  }

  // Log pour analytics/monitoring (à implémenter avec Sentry ou similaire)
  // Ici on pourrait envoyer à un service de monitoring
}

export async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  delay: number = 1000
): Promise<T> {
  let lastError: Error;
  
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      if (attempt < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay * (attempt + 1)));
      }
    }
  }
  
  throw lastError!;
}

export function isNetworkError(error: unknown): boolean {
  if (error instanceof Error) {
    return error.message.toLowerCase().includes('network') ||
           error.message.toLowerCase().includes('fetch');
  }
  return false;
}
