import { useEmailVerification } from "@/hooks/useEmailVerification";
import { EmailVerificationPrompt } from "@/components/auth/EmailVerificationPrompt";
import { useNavigate, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export default function VerifyEmail() {
  const { isEmailVerified, needsVerification, loading, email: authEmail } = useEmailVerification();
  const { user } = useAuth();
  const location = useLocation();
  const [pendingEmail, setPendingEmail] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedEmail = sessionStorage.getItem('pendingEmailVerification');
    const stateEmail = location.state?.email;
    
    if (stateEmail) {
      setPendingEmail(stateEmail);
    } else if (storedEmail) {
      setPendingEmail(storedEmail);
    }
  }, [location.state]);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN') {
        sessionStorage.removeItem('pendingEmailVerification');
        navigate("/");
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  useEffect(() => {
    if (!loading && isEmailVerified) {
      sessionStorage.removeItem('pendingEmailVerification');
      navigate("/");
    }
  }, [isEmailVerified, loading, navigate]);

  if (loading) {
    return null;
  }

  if (isEmailVerified) {
    return null;
  }

  const displayEmail = authEmail || pendingEmail;

  if (!displayEmail && !needsVerification && !user) {
    navigate("/auth");
    return null;
  }

  return <EmailVerificationPrompt email={displayEmail || "votre adresse email"} />;
}
