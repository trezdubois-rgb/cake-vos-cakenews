import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { FileText } from "lucide-react";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <FileText className="h-6 w-6 text-primary" data-testid="icon-terms" />
              <CardTitle className="text-2xl" data-testid="text-terms-title">
                Conditions Générales d'Utilisation
              </CardTitle>
            </div>
            <CardDescription>Dernière mise à jour : {new Date().toLocaleDateString('fr-FR')}</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-6 text-sm">
                <section>
                  <h2 className="text-lg font-semibold mb-2">1. Acceptation des Conditions</h2>
                  <p className="text-muted-foreground">
                    En accédant et en utilisant Cake, vous acceptez d'être lié par ces conditions générales d'utilisation. 
                    Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser notre service.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">2. Description du Service</h2>
                  <p className="text-muted-foreground">
                    Cake est une plateforme de découverte et de partage d'actualités qui permet aux utilisateurs de consulter, créer et interagir 
                    avec du contenu éditorial. Le service est accessible en mode invité limité ou via un compte utilisateur.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">3. Inscription et Compte</h2>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-4">
                    <li>Vous devez fournir des informations exactes et à jour lors de l'inscription</li>
                    <li>Vous êtes responsable de la sécurité de votre compte et de votre mot de passe</li>
                    <li>Vous devez avoir au moins 13 ans pour créer un compte</li>
                    <li>Un compte ne peut être transféré à une autre personne</li>
                    <li>Vous devez notifier immédiatement toute utilisation non autorisée de votre compte</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">4. Mode Invité</h2>
                  <p className="text-muted-foreground">
                    Le mode invité offre un accès limité à la plateforme (5 minutes de navigation). Pour bénéficier de toutes les fonctionnalités, 
                    vous devez créer un compte. Les sessions invitées sont soumises à des restrictions temporelles et peuvent être bloquées en cas 
                    d'abus.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">5. Contenu Utilisateur</h2>
                  <p className="text-muted-foreground mb-2">En publiant du contenu sur Cake, vous déclarez et garantissez que :</p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-4">
                    <li>Vous détenez tous les droits nécessaires sur le contenu publié</li>
                    <li>Le contenu ne viole aucun droit de propriété intellectuelle</li>
                    <li>Le contenu respecte nos règles de la communauté</li>
                    <li>Vous accordez à Cake une licence mondiale, non exclusive et gratuite d'utilisation</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">6. Règles de Conduite</h2>
                  <p className="text-muted-foreground mb-2">Il est interdit de :</p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-4">
                    <li>Publier du contenu illégal, offensant ou discriminatoire</li>
                    <li>Harceler ou intimider d'autres utilisateurs</li>
                    <li>Diffuser du spam ou du contenu promotionnel non sollicité</li>
                    <li>Usurper l'identité d'une autre personne</li>
                    <li>Utiliser des bots ou des scripts automatisés sans autorisation</li>
                    <li>Tenter de contourner les mesures de sécurité</li>
                    <li>Collecter des données d'autres utilisateurs sans consentement</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">7. Propriété Intellectuelle</h2>
                  <p className="text-muted-foreground">
                    Tous les droits de propriété intellectuelle sur la plateforme Cake, incluant le design, le code, les logos et les marques, 
                    appartiennent à Cake ou à ses concédants de licence. Vous ne pouvez pas reproduire, modifier ou distribuer notre contenu 
                    sans autorisation écrite préalable.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">8. Modération et Suspension</h2>
                  <p className="text-muted-foreground">
                    Nous nous réservons le droit de modérer, supprimer ou refuser tout contenu, et de suspendre ou résilier des comptes qui 
                    violent ces conditions ou nos règles de la communauté, sans préavis ni obligation de justification.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">9. Limitation de Responsabilité</h2>
                  <p className="text-muted-foreground">
                    Cake est fourni "tel quel" sans garantie d'aucune sorte. Nous ne sommes pas responsables des dommages directs ou indirects 
                    résultant de l'utilisation ou de l'impossibilité d'utiliser le service. Nous ne garantissons pas la disponibilité continue 
                    du service.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">10. Résiliation</h2>
                  <p className="text-muted-foreground">
                    Vous pouvez résilier votre compte à tout moment depuis vos paramètres. Nous pouvons suspendre ou résilier votre accès en cas 
                    de violation de ces conditions. Les sections relatives à la propriété intellectuelle et à la limitation de responsabilité 
                    survivent à la résiliation.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">11. Modifications du Service</h2>
                  <p className="text-muted-foreground">
                    Nous nous réservons le droit de modifier, suspendre ou interrompre tout ou partie du service à tout moment, avec ou sans 
                    préavis. Nous ne serons pas responsables envers vous ou des tiers de toute modification ou interruption du service.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">12. Droit Applicable</h2>
                  <p className="text-muted-foreground">
                    Ces conditions sont régies par le droit français. Tout litige sera soumis à la compétence exclusive des tribunaux français.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">13. Contact</h2>
                  <p className="text-muted-foreground">
                    Pour toute question concernant ces conditions d'utilisation, contactez-nous à : legal@cake-app.com
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">14. Modifications des Conditions</h2>
                  <p className="text-muted-foreground">
                    Nous pouvons modifier ces conditions à tout moment. Les modifications significatives vous seront notifiées par email ou via 
                    une notification sur le site. Votre utilisation continue du service après les modifications constitue votre acceptation des 
                    nouvelles conditions.
                  </p>
                </section>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
