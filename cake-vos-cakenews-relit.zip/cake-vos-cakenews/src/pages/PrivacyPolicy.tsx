import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Shield } from "lucide-react";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="h-6 w-6 text-primary" data-testid="icon-privacy" />
              <CardTitle className="text-2xl" data-testid="text-privacy-title">
                Politique de Confidentialité
              </CardTitle>
            </div>
            <CardDescription>Dernière mise à jour : {new Date().toLocaleDateString('fr-FR')}</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px] pr-4">
              <div className="space-y-6 text-sm">
                <section>
                  <h2 className="text-lg font-semibold mb-2">1. Introduction</h2>
                  <p className="text-muted-foreground">
                    Bienvenue sur Cake. Nous respectons votre vie privée et nous nous engageons à protéger vos données personnelles. 
                    Cette politique de confidentialité vous informe sur la manière dont nous collectons, utilisons et protégeons vos informations.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">2. Données Collectées</h2>
                  <p className="text-muted-foreground mb-2">Nous collectons les types de données suivants :</p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-4">
                    <li>Informations de compte : email, nom d'affichage</li>
                    <li>Données de profil : avatar, préférences de contenu</li>
                    <li>Données d'utilisation : articles consultés, commentaires, interactions</li>
                    <li>Données techniques : adresse IP, type de navigateur, données de session</li>
                    <li>Cookies et technologies similaires pour améliorer votre expérience</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">3. Utilisation des Données</h2>
                  <p className="text-muted-foreground mb-2">Nous utilisons vos données pour :</p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-4">
                    <li>Fournir et améliorer nos services</li>
                    <li>Personnaliser votre flux d'actualités</li>
                    <li>Envoyer des notifications importantes</li>
                    <li>Prévenir la fraude et assurer la sécurité</li>
                    <li>Respecter nos obligations légales</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">4. Base Légale du Traitement</h2>
                  <p className="text-muted-foreground">
                    Conformément au RGPD, nous traitons vos données personnelles sur la base de :
                  </p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-4 mt-2">
                    <li>Votre consentement explicite</li>
                    <li>L'exécution d'un contrat</li>
                    <li>Nos intérêts légitimes</li>
                    <li>Le respect d'obligations légales</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">5. Partage des Données</h2>
                  <p className="text-muted-foreground">
                    Nous ne vendons jamais vos données personnelles. Nous pouvons partager vos informations avec :
                  </p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-4 mt-2">
                    <li>Fournisseurs de services (hébergement, analytics)</li>
                    <li>Autorités légales si requis par la loi</li>
                  </ul>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">6. Vos Droits RGPD</h2>
                  <p className="text-muted-foreground mb-2">Conformément au RGPD, vous disposez des droits suivants :</p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 ml-4">
                    <li><strong>Droit d'accès</strong> : consulter vos données personnelles</li>
                    <li><strong>Droit de rectification</strong> : corriger vos données inexactes</li>
                    <li><strong>Droit à l'effacement</strong> : supprimer vos données</li>
                    <li><strong>Droit à la portabilité</strong> : récupérer vos données</li>
                    <li><strong>Droit d'opposition</strong> : refuser certains traitements</li>
                    <li><strong>Droit de limitation</strong> : restreindre le traitement</li>
                  </ul>
                  <p className="text-muted-foreground mt-2">
                    Pour exercer ces droits, contactez-nous à : privacy@cake-app.com
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">7. Sécurité des Données</h2>
                  <p className="text-muted-foreground">
                    Nous mettons en œuvre des mesures de sécurité techniques et organisationnelles appropriées pour protéger vos données contre 
                    tout accès non autorisé, modification, divulgation ou destruction.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">8. Conservation des Données</h2>
                  <p className="text-muted-foreground">
                    Nous conservons vos données personnelles aussi longtemps que nécessaire pour fournir nos services et respecter nos obligations légales. 
                    Les comptes inactifs depuis plus de 3 ans peuvent être supprimés.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">9. Cookies</h2>
                  <p className="text-muted-foreground">
                    Nous utilisons des cookies essentiels pour le fonctionnement du site. Vous pouvez gérer vos préférences de cookies dans les paramètres 
                    de votre navigateur. L'utilisation de cookies non essentiels nécessite votre consentement explicite.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">10. Transferts Internationaux</h2>
                  <p className="text-muted-foreground">
                    Vos données peuvent être transférées et traitées dans des pays hors de l'Union Européenne. Nous veillons à ce que ces transferts 
                    respectent les exigences du RGPD et soient protégés par des clauses contractuelles types approuvées par la Commission Européenne.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">11. Modifications</h2>
                  <p className="text-muted-foreground">
                    Nous pouvons modifier cette politique de confidentialité. Les modifications significatives vous seront notifiées par email ou via 
                    une notification sur le site.
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">12. Contact</h2>
                  <p className="text-muted-foreground">
                    Pour toute question concernant cette politique de confidentialité ou vos données personnelles, contactez-nous à :
                  </p>
                  <p className="text-muted-foreground mt-2">
                    <strong>Email:</strong> privacy@cake-app.com<br />
                    <strong>DPO:</strong> dpo@cake-app.com
                  </p>
                </section>

                <section>
                  <h2 className="text-lg font-semibold mb-2">13. Autorité de Contrôle</h2>
                  <p className="text-muted-foreground">
                    Si vous estimez que vos droits ne sont pas respectés, vous pouvez déposer une plainte auprès de la CNIL (Commission Nationale de 
                    l'Informatique et des Libertés) ou de votre autorité de protection des données locale.
                  </p>
                </section>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
