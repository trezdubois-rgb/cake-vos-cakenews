-- Migration: Système de versions linguistiques et stylistiques
-- Date: 2025-11-15
-- Description: Ajout de la table article_versions et amélioration des préférences utilisateur

-- Créer la table article_versions pour gérer les versions multiples
CREATE TABLE IF NOT EXISTS public.article_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  article_id UUID NOT NULL REFERENCES public.articles(id) ON DELETE CASCADE,
  language_code VARCHAR(10) NOT NULL, -- fr, mo, ln, ewe, etc.
  style VARCHAR(20) NOT NULL DEFAULT 'standard', -- standard, argot
  content_html TEXT NOT NULL,
  audio_url TEXT,
  approved_by_cultural_partner BOOLEAN DEFAULT false,
  cultural_validator_id UUID REFERENCES auth.users(id),
  cultural_license_document_url TEXT,
  moderation_status VARCHAR(20) DEFAULT 'pending' CHECK (moderation_status IN ('pending', 'approved', 'rejected')),
  moderated_by UUID REFERENCES auth.users(id),
  moderated_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE(article_id, language_code, style)
);

-- Enable RLS
ALTER TABLE public.article_versions ENABLE ROW LEVEL SECURITY;

-- RLS Policies pour article_versions
CREATE POLICY "Versions are viewable by everyone for published articles"
  ON public.article_versions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.articles
      WHERE articles.id = article_versions.article_id
      AND articles.published = true
    )
    OR 
    EXISTS (
      SELECT 1 FROM public.articles
      WHERE articles.id = article_versions.article_id
      AND (articles.author_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role))
    )
  );

CREATE POLICY "Admins and authors can create versions"
  ON public.article_versions FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.articles
      WHERE articles.id = article_versions.article_id
      AND (articles.author_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role))
    )
  );

CREATE POLICY "Admins and authors can update their versions"
  ON public.article_versions FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.articles
      WHERE articles.id = article_versions.article_id
      AND (articles.author_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role))
    )
  );

CREATE POLICY "Admins can delete versions"
  ON public.article_versions FOR DELETE
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

-- Créer des index pour les performances
CREATE INDEX IF NOT EXISTS idx_article_versions_article_id ON public.article_versions(article_id);
CREATE INDEX IF NOT EXISTS idx_article_versions_language_style ON public.article_versions(language_code, style);
CREATE INDEX IF NOT EXISTS idx_article_versions_moderation ON public.article_versions(moderation_status);

-- Mettre à jour la table profiles avec des préférences enrichies
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS preferred_language VARCHAR(10) DEFAULT 'fr',
ADD COLUMN IF NOT EXISTS preferred_style VARCHAR(20) DEFAULT 'standard',
ADD COLUMN IF NOT EXISTS favorite_categories TEXT[] DEFAULT '{}';

-- Créer un index GIN pour les recherches sur les préférences
CREATE INDEX IF NOT EXISTS idx_profiles_preferences_gin ON public.profiles USING GIN (preferences);
CREATE INDEX IF NOT EXISTS idx_profiles_favorite_categories ON public.profiles USING GIN (favorite_categories);

-- Trigger pour updated_at sur article_versions
CREATE TRIGGER update_article_versions_updated_at
BEFORE UPDATE ON public.article_versions
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

-- Fonction pour obtenir la version appropriée d'un article selon les préférences utilisateur
CREATE OR REPLACE FUNCTION public.get_article_version(
  p_article_id UUID,
  p_language_code VARCHAR DEFAULT 'fr',
  p_style VARCHAR DEFAULT 'standard'
)
RETURNS TABLE (
  id UUID,
  article_id UUID,
  language_code VARCHAR,
  style VARCHAR,
  content_html TEXT,
  audio_url TEXT,
  approved_by_cultural_partner BOOLEAN
) 
LANGUAGE plpgsql
STABLE
AS $$
BEGIN
  -- Essayer de trouver la version exacte demandée
  RETURN QUERY
  SELECT 
    av.id,
    av.article_id,
    av.language_code,
    av.style,
    av.content_html,
    av.audio_url,
    av.approved_by_cultural_partner
  FROM public.article_versions av
  WHERE av.article_id = p_article_id
    AND av.language_code = p_language_code
    AND av.style = p_style
    AND av.moderation_status = 'approved'
  LIMIT 1;
  
  -- Si rien trouvé, fallback vers standard dans la même langue
  IF NOT FOUND THEN
    RETURN QUERY
    SELECT 
      av.id,
      av.article_id,
      av.language_code,
      av.style,
      av.content_html,
      av.audio_url,
      av.approved_by_cultural_partner
    FROM public.article_versions av
    WHERE av.article_id = p_article_id
      AND av.language_code = p_language_code
      AND av.style = 'standard'
      AND av.moderation_status = 'approved'
    LIMIT 1;
  END IF;
  
  -- Si toujours rien, fallback vers français standard
  IF NOT FOUND THEN
    RETURN QUERY
    SELECT 
      av.id,
      av.article_id,
      av.language_code,
      av.style,
      av.content_html,
      av.audio_url,
      av.approved_by_cultural_partner
    FROM public.article_versions av
    WHERE av.article_id = p_article_id
      AND av.language_code = 'fr'
      AND av.style = 'standard'
      AND av.moderation_status = 'approved'
    LIMIT 1;
  END IF;
END;
$$;

-- Fonction pour obtenir toutes les versions disponibles d'un article
CREATE OR REPLACE FUNCTION public.get_available_versions(p_article_id UUID)
RETURNS TABLE (
  language_code VARCHAR,
  style VARCHAR,
  has_audio BOOLEAN
)
LANGUAGE sql
STABLE
AS $$
  SELECT 
    language_code,
    style,
    (audio_url IS NOT NULL AND audio_url != '') as has_audio
  FROM public.article_versions
  WHERE article_id = p_article_id
    AND moderation_status = 'approved'
  ORDER BY 
    CASE language_code 
      WHEN 'fr' THEN 1 
      ELSE 2 
    END,
    CASE style 
      WHEN 'standard' THEN 1 
      WHEN 'argot' THEN 2 
      ELSE 3 
    END;
$$;

-- Ajouter un commentaire pour la documentation
COMMENT ON TABLE public.article_versions IS 'Stocke les différentes versions linguistiques et stylistiques des articles';
COMMENT ON COLUMN public.article_versions.language_code IS 'Code ISO de la langue (fr, mo, ln, ewe, etc.)';
COMMENT ON COLUMN public.article_versions.style IS 'Style de rédaction (standard, argot)';
COMMENT ON COLUMN public.article_versions.approved_by_cultural_partner IS 'Indique si la version en langue traditionnelle a été validée par un partenaire culturel';
COMMENT ON COLUMN public.article_versions.cultural_license_document_url IS 'URL du document de licence pour les enregistrements en langue locale';
