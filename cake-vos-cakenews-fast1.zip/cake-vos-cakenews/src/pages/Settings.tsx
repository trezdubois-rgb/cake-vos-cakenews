import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Save, Languages, BookmarkCheck, Bell } from "lucide-react";
import { toast } from "sonner";

interface Category {
  id: string;
  name: string;
  icon: string | null;
}

interface UserPreferences {
  preferred_language: string;
  preferred_style: string;
  favorite_categories: string[];
  auto_play_audio: boolean;
  email_notifications: boolean;
}

const languages = [
  { code: 'fr', name: 'Français' },
  { code: 'mo', name: 'Mooré' },
  { code: 'ln', name: 'Lingala' },
  { code: 'ewe', name: 'Ewe' },
  { code: 'yo', name: 'Yoruba' },
  { code: 'ha', name: 'Haoussa' },
];

const styles = [
  { value: 'standard', label: 'Standard' },
  { value: 'argot', label: 'Argot' },
];

export default function Settings() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [preferences, setPreferences] = useState<UserPreferences>({
    preferred_language: 'fr',
    preferred_style: 'standard',
    favorite_categories: [],
    auto_play_audio: false,
    email_notifications: true,
  });

  useEffect(() => {
    if (!user) {
      navigate("/auth");
      return;
    }

    fetchData();
  }, [user, navigate]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Charger les catégories
      const { data: categoriesData, error: categoriesError } = await supabase
        .from("categories")
        .select("*")
        .order("name");

      if (categoriesError) throw categoriesError;
      setCategories(categoriesData || []);

      // Charger les préférences utilisateur
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("preferences")
        .eq("id", user!.id)
        .single();

      if (profileError) throw profileError;

      if (profileData?.preferences) {
        const prefs = profileData.preferences as any;
        setPreferences({
          preferred_language: prefs.preferred_language || 'fr',
          preferred_style: prefs.preferred_style || 'standard',
          favorite_categories: prefs.favorite_categories || [],
          auto_play_audio: prefs.auto_play_audio || false,
          email_notifications: prefs.email_notifications !== false, // true par défaut
        });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Erreur lors du chargement des préférences");
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .update({
          preferences: preferences as any
        })
        .eq("id", user!.id);

      if (error) throw error;

      toast.success("Préférences enregistrées avec succès");
    } catch (error) {
      console.error("Error saving preferences:", error);
      toast.error("Erreur lors de l'enregistrement");
    } finally {
      setSaving(false);
    }
  };

  const toggleCategory = (categoryId: string) => {
    setPreferences(prev => ({
      ...prev,
      favorite_categories: prev.favorite_categories.includes(categoryId)
        ? prev.favorite_categories.filter(id => id !== categoryId)
        : [...prev.favorite_categories, categoryId],
    }));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-4 md:p-8">
        <Skeleton className="h-12 w-64 mb-8" />
        <div className="space-y-4">
          <Skeleton className="h-32" />
          <Skeleton className="h-48" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 pb-20 md:pb-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Préférences</h1>
          <p className="text-muted-foreground">
            Personnalisez votre expérience de lecture sur CAKENEWS
          </p>
        </div>

        <div className="space-y-6">
          {/* Préférences linguistiques */}
          <Card className="p-6 space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <Languages className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold">Langue et style de lecture</h2>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="language">Langue préférée</Label>
                <Select
                  value={preferences.preferred_language}
                  onValueChange={(value) => setPreferences({ ...preferences, preferred_language: value })}
                >
                  <SelectTrigger id="language" data-testid="select-language">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground mt-1">
                  Les articles seront affichés dans cette langue quand disponible
                </p>
              </div>

              <div>
                <Label htmlFor="style">Style préféré</Label>
                <Select
                  value={preferences.preferred_style}
                  onValueChange={(value) => setPreferences({ ...preferences, preferred_style: value })}
                >
                  <SelectTrigger id="style" data-testid="select-style">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {styles.map(style => (
                      <SelectItem key={style.value} value={style.value}>
                        {style.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground mt-1">
                  Choisissez entre français standard ou argot
                </p>
              </div>
            </div>
          </Card>

          {/* Catégories favorites */}
          <Card className="p-6 space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <BookmarkCheck className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold">Catégories favorites</h2>
            </div>

            <p className="text-sm text-muted-foreground">
              Sélectionnez les catégories qui vous intéressent pour personnaliser votre flux d'actualités
            </p>

            <div className="flex flex-wrap gap-2">
              {categories.map(category => {
                const isSelected = preferences.favorite_categories.includes(category.id);
                return (
                  <Badge
                    key={category.id}
                    variant={isSelected ? "default" : "outline"}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? '' : 'hover-elevate'
                    }`}
                    onClick={() => toggleCategory(category.id)}
                    data-testid={`badge-category-${category.id}`}
                  >
                    {category.icon} {category.name}
                  </Badge>
                );
              })}
            </div>
          </Card>

          {/* Options supplémentaires */}
          <Card className="p-6 space-y-4">
            <div className="flex items-center gap-2 mb-4">
              <Bell className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-semibold">Options supplémentaires</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="auto-audio">Lecture audio automatique</Label>
                  <p className="text-sm text-muted-foreground">
                    Lancer automatiquement la lecture audio des articles
                  </p>
                </div>
                <Switch
                  id="auto-audio"
                  checked={preferences.auto_play_audio}
                  onCheckedChange={(checked) => setPreferences({ ...preferences, auto_play_audio: checked })}
                  data-testid="switch-auto-audio"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="notifications">Notifications par email</Label>
                  <p className="text-sm text-muted-foreground">
                    Recevoir des emails pour les nouveaux articles dans vos catégories favorites
                  </p>
                </div>
                <Switch
                  id="notifications"
                  checked={preferences.email_notifications}
                  onCheckedChange={(checked) => setPreferences({ ...preferences, email_notifications: checked })}
                  data-testid="switch-notifications"
                />
              </div>
            </div>
          </Card>

          {/* Bouton de sauvegarde */}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => navigate("/")}>
              Annuler
            </Button>
            <Button onClick={handleSave} disabled={saving} data-testid="button-save-preferences">
              <Save className="mr-2 h-4 w-4" />
              {saving ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
