import { Link } from "react-router-dom";
import { usePersonalizedFeed } from "@/hooks/usePersonalizedFeed";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Settings, Sparkles, TrendingUp, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

export default function MyFeed() {
  const { articles, loading, preferences } = usePersonalizedFeed();

  const hasFavorites = preferences?.favorite_categories?.length > 0;

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-4 md:p-8 pb-20 md:pb-8">
        <div className="max-w-6xl mx-auto">
          <Skeleton className="h-12 w-64 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <Skeleton key={i} className="h-64" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 pb-20 md:pb-8">
      <div className="max-w-6xl mx-auto">
        {/* En-tête */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold flex items-center gap-3 mb-2">
              <Sparkles className="h-8 w-8 text-primary" />
              Mon flux personnalisé
            </h1>
            <p className="text-muted-foreground">
              {hasFavorites
                ? "Articles sélectionnés selon vos préférences"
                : "Découvrez les articles populaires"}
            </p>
          </div>
          <Link to="/settings">
            <Button variant="outline" data-testid="button-settings">
              <Settings className="mr-2 h-4 w-4" />
              Préférences
            </Button>
          </Link>
        </div>

        {/* Message si pas de préférences configurées */}
        {!hasFavorites && (
          <Card className="p-6 mb-8 bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
            <div className="flex items-start gap-4">
              <Sparkles className="h-6 w-6 text-primary mt-1" />
              <div className="flex-1">
                <h3 className="font-semibold text-lg mb-2">Personnalisez votre expérience</h3>
                <p className="text-muted-foreground mb-4">
                  Configurez vos préférences pour recevoir des recommandations adaptées à vos centres
                  d'intérêt.
                </p>
                <Link to="/settings">
                  <Button data-testid="button-configure-preferences">
                    <Settings className="mr-2 h-4 w-4" />
                    Configurer mes préférences
                  </Button>
                </Link>
              </div>
            </div>
          </Card>
        )}

        {/* Statistiques rapides */}
        {hasFavorites && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card className="p-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <BookmarkCheck className="h-4 w-4" />
                Catégories favorites
              </div>
              <div className="text-2xl font-bold">{preferences.favorite_categories.length}</div>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <TrendingUp className="h-4 w-4" />
                Articles suggérés
              </div>
              <div className="text-2xl font-bold">{articles.length}</div>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <Languages className="h-4 w-4" />
                Langue préférée
              </div>
              <div className="text-lg font-semibold">
                {preferences.preferred_language === 'fr' ? 'Français' : preferences.preferred_language.toUpperCase()}
              </div>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <FileText className="h-4 w-4" />
                Style
              </div>
              <div className="text-lg font-semibold capitalize">{preferences.preferred_style || 'Standard'}</div>
            </Card>
          </div>
        )}

        {/* Articles */}
        {articles.length === 0 ? (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground mb-4">Aucun article disponible pour le moment</p>
            <Link to="/settings">
              <Button variant="outline">Modifier mes préférences</Button>
            </Link>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article, index) => {
              const isFavoriteCategory = hasFavorites && preferences.favorite_categories.includes(article.category_id);

              return (
                <Link key={article.id} to={`/article/${article.id}`}>
                  <Card className="overflow-hidden hover-elevate transition-all h-full" data-testid={`card-article-${article.id}`}>
                    {/* Image */}
                    {article.hero_image_url && (
                      <div className="relative">
                        <img
                          src={article.hero_image_url}
                          alt={article.title}
                          className="w-full h-48 object-cover"
                        />
                        {isFavoriteCategory && (
                          <Badge className="absolute top-2 right-2 bg-primary">
                            <Sparkles className="h-3 w-3 mr-1" />
                            Pour vous
                          </Badge>
                        )}
                        {index === 0 && (
                          <Badge variant="outline" className="absolute top-2 left-2 bg-background/90">
                            <TrendingUp className="h-3 w-3 mr-1" />
                            Tendance
                          </Badge>
                        )}
                      </div>
                    )}

                    <div className="p-4 space-y-3">
                      {/* Catégorie */}
                      {article.category && (
                        <Badge variant="outline" className="text-xs">
                          {article.category.icon} {article.category.name}
                        </Badge>
                      )}

                      {/* Titre */}
                      <h3 className="font-semibold text-lg line-clamp-2">{article.title}</h3>

                      {/* Extrait */}
                      {article.excerpt && (
                        <p className="text-sm text-muted-foreground line-clamp-2">{article.excerpt}</p>
                      )}

                      {/* Auteur et date */}
                      <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={article.author.avatar_url || undefined} />
                            <AvatarFallback>
                              {article.author.display_name?.[0]?.toUpperCase() || "A"}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{article.author.display_name}</span>
                        </div>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatDistanceToNow(new Date(article.published_at), {
                            addSuffix: true,
                            locale: fr,
                          })}
                        </span>
                      </div>
                    </div>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
