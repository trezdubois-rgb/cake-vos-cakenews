import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle, XCircle, Clock, Languages, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

interface PendingVersion {
  id: string;
  article_id: string;
  language_code: string;
  style: string;
  content_html: string;
  audio_url?: string;
  moderation_status: string;
  created_at: string;
  article: {
    title: string;
    author: {
      display_name: string;
    };
  };
}

export default function Moderation() {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [pendingSlangVersions, setPendingSlangVersions] = useState<PendingVersion[]>([]);
  const [pendingCulturalVersions, setPendingCulturalVersions] = useState<PendingVersion[]>([]);

  useEffect(() => {
    if (!user || !isAdmin) {
      navigate("/");
      return;
    }

    fetchPendingVersions();
  }, [user, isAdmin, navigate]);

  const fetchPendingVersions = async () => {
    setLoading(true);
    try {
      // Récupérer les versions argotiques en attente
      const { data: slangData, error: slangError } = await supabase
        .from("article_versions" as any)
        .select(`
          *,
          article:articles!inner (
            title,
            author:profiles!articles_author_id_fkey (
              display_name
            )
          )
        `)
        .eq("style", "argot")
        .eq("moderation_status", "pending");

      if (slangError) throw slangError;

      // Récupérer les versions culturelles en attente
      const { data: culturalData, error: culturalError } = await supabase
        .from("article_versions" as any)
        .select(`
          *,
          article:articles!inner (
            title,
            author:profiles!articles_author_id_fkey (
              display_name
            )
          )
        `)
        .neq("language_code", "fr")
        .eq("moderation_status", "pending_cultural");

      if (culturalError) throw culturalError;

      setPendingSlangVersions((slangData as any) || []);
      setPendingCulturalVersions((culturalData as any) || []);
    } catch (error) {
      console.error("Error fetching pending versions:", error);
      toast.error("Erreur lors du chargement des versions en attente");
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (versionId: string, isCultural: boolean) => {
    try {
      const { error } = await supabase
        .from("article_versions" as any)
        .update({
          moderation_status: "approved",
          approved_by_cultural_partner: isCultural,
          moderated_at: new Date().toISOString(),
          moderated_by: user?.id,
        } as any)
        .eq("id", versionId);

      if (error) throw error;

      toast.success(isCultural ? "Version culturelle approuvée" : "Version argotique approuvée");
      fetchPendingVersions();
    } catch (error) {
      console.error("Error approving version:", error);
      toast.error("Erreur lors de l'approbation");
    }
  };

  const handleReject = async (versionId: string, reason?: string) => {
    try {
      const { error } = await supabase
        .from("article_versions" as any)
        .update({
          moderation_status: "rejected",
          moderation_notes: reason || "Version rejetée",
          moderated_at: new Date().toISOString(),
          moderated_by: user?.id,
        } as any)
        .eq("id", versionId);

      if (error) throw error;

      toast.success("Version rejetée");
      fetchPendingVersions();
    } catch (error) {
      console.error("Error rejecting version:", error);
      toast.error("Erreur lors du rejet");
    }
  };

  const VersionCard = ({ version, isCultural }: { version: PendingVersion; isCultural: boolean }) => (
    <Card className="p-6 space-y-4" data-testid={`card-version-${version.id}`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <h3 className="font-semibold text-lg mb-1">{version.article.title}</h3>
          <div className="flex gap-2 flex-wrap items-center text-sm text-muted-foreground mb-2">
            <span>Par {version.article.author.display_name}</span>
            <span>•</span>
            <Badge variant="outline" className="text-xs">
              {version.language_code === 'fr' ? 'Argot' : getLanguageName(version.language_code)}
            </Badge>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {new Date(version.created_at).toLocaleDateString('fr-FR')}
            </span>
          </div>
        </div>
        {isCultural && (
          <Badge variant="outline" className="bg-purple-50 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
            <Languages className="h-3 w-3 mr-1" />
            Validation culturelle requise
          </Badge>
        )}
      </div>

      <div
        className="prose dark:prose-invert max-w-none bg-muted/50 rounded-md p-4 max-h-64 overflow-y-auto"
        dangerouslySetInnerHTML={{ __html: version.content_html }}
        data-testid={`content-${version.id}`}
      />

      {version.audio_url && (
        <div>
          <p className="text-sm font-medium mb-2">Version audio :</p>
          <audio controls src={version.audio_url} className="w-full" data-testid={`audio-${version.id}`} />
        </div>
      )}

      <div className="flex gap-2 pt-2">
        <Button
          onClick={() => handleApprove(version.id, isCultural)}
          className="flex-1"
          data-testid={`button-approve-${version.id}`}
        >
          <CheckCircle className="mr-2 h-4 w-4" />
          Approuver
        </Button>
        <Button
          onClick={() => handleReject(version.id)}
          variant="destructive"
          className="flex-1"
          data-testid={`button-reject-${version.id}`}
        >
          <XCircle className="mr-2 h-4 w-4" />
          Rejeter
        </Button>
      </div>
    </Card>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-background p-4 md:p-8">
        <Skeleton className="h-12 w-64 mb-8" />
        <div className="space-y-4">
          <Skeleton className="h-48" />
          <Skeleton className="h-48" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 pb-20 md:pb-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Modération des versions</h1>
          <p className="text-muted-foreground">
            Validez les versions argotiques et les traductions en langues traditionnelles
          </p>
        </div>

        <Tabs defaultValue="slang" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="slang" className="relative">
              Versions argotiques
              {pendingSlangVersions.length > 0 && (
                <Badge variant="destructive" className="ml-2 text-xs">
                  {pendingSlangVersions.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="cultural" className="relative">
              Langues traditionnelles
              {pendingCulturalVersions.length > 0 && (
                <Badge variant="destructive" className="ml-2 text-xs">
                  {pendingCulturalVersions.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="slang" className="space-y-4">
            {pendingSlangVersions.length === 0 ? (
              <Card className="p-12 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                <p className="text-muted-foreground">Aucune version argotique en attente de validation</p>
              </Card>
            ) : (
              pendingSlangVersions.map(version => (
                <VersionCard key={version.id} version={version} isCultural={false} />
              ))
            )}
          </TabsContent>

          <TabsContent value="cultural" className="space-y-4">
            <div className="bg-purple-50 dark:bg-purple-950 border border-purple-200 dark:border-purple-800 rounded-md p-4 mb-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-purple-600 dark:text-purple-400 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-purple-900 dark:text-purple-100 mb-1">
                    Importance de la validation culturelle
                  </h3>
                  <p className="text-sm text-purple-800 dark:text-purple-200">
                    Les versions en langues traditionnelles doivent être validées par un locuteur natif ou un
                    partenaire culturel pour garantir la justesse linguistique et le respect des sensibilités
                    culturelles.
                  </p>
                </div>
              </div>
            </div>

            {pendingCulturalVersions.length === 0 ? (
              <Card className="p-12 text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                <p className="text-muted-foreground">
                  Aucune version culturelle en attente de validation
                </p>
              </Card>
            ) : (
              pendingCulturalVersions.map(version => (
                <VersionCard key={version.id} version={version} isCultural={true} />
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

const getLanguageName = (code: string): string => {
  const names: Record<string, string> = {
    mo: "Mooré",
    ln: "Lingala",
    ewe: "Ewe",
    yo: "Yoruba",
    ha: "Haoussa",
  };
  return names[code] || code;
};
