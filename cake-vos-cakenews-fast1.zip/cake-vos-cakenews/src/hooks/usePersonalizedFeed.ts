import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";

interface Article {
  id: string;
  title: string;
  excerpt: string;
  hero_image_url: string;
  published_at: string;
  category_id: string;
  view_count: number;
  category: {
    name: string;
    icon: string;
  };
  author: {
    display_name: string;
    avatar_url: string;
  };
}

export const usePersonalizedFeed = () => {
  const { user } = useAuth();
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [preferences, setPreferences] = useState<any>(null);

  useEffect(() => {
    if (user) {
      fetchPersonalizedFeed();
    } else {
      fetchDefaultFeed();
    }
  }, [user]);

  const fetchPersonalizedFeed = async () => {
    setLoading(true);
    try {
      // Charger les préférences de l'utilisateur
      const { data: profileData } = await supabase
        .from("profiles")
        .select("preferences")
        .eq("id", user?.id)
        .single();

      const userPrefs = (profileData?.preferences as any) || {};
      setPreferences(userPrefs);

      const favoriteCategories = userPrefs.favorite_categories || [];

      let query = supabase
        .from("articles")
        .select(`
          *,
          category:categories (
            name,
            icon
          ),
          author:profiles!articles_author_id_fkey (
            display_name,
            avatar_url
          )
        `)
        .eq("published", true)
        .order("published_at", { ascending: false });

      // Si l'utilisateur a des catégories favorites, prioriser celles-ci
      if (favoriteCategories.length > 0) {
        // Récupérer les articles des catégories favorites
        const { data: favoriteArticles } = await query
          .in("category_id", favoriteCategories)
          .limit(10);

        // Récupérer quelques articles d'autres catégories pour la découverte
        const { data: otherArticles } = await supabase
          .from("articles")
          .select(`
            *,
            category:categories (
              name,
              icon
            ),
            author:profiles!articles_author_id_fkey (
              display_name,
              avatar_url
            )
          `)
          .eq("published", true)
          .not("category_id", "in", `(${favoriteCategories.join(",")})`)
          .order("view_count", { ascending: false })
          .limit(5);

        // Combiner et mélanger les résultats
        const combined = [
          ...(favoriteArticles || []),
          ...(otherArticles || []),
        ];

        // Tri par pertinence (favoris en premier, puis par date)
        const sorted = combined.sort((a, b) => {
          const aIsFavorite = favoriteCategories.includes(a.category_id);
          const bIsFavorite = favoriteCategories.includes(b.category_id);

          if (aIsFavorite && !bIsFavorite) return -1;
          if (!aIsFavorite && bIsFavorite) return 1;

          return new Date(b.published_at).getTime() - new Date(a.published_at).getTime();
        });

        setArticles(sorted as Article[]);
      } else {
        // Pas de préférences, afficher les articles populaires
        const { data } = await query.limit(15);
        setArticles((data as Article[]) || []);
      }
    } catch (error) {
      console.error("Error fetching personalized feed:", error);
      fetchDefaultFeed();
    } finally {
      setLoading(false);
    }
  };

  const fetchDefaultFeed = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("articles")
        .select(`
          *,
          category:categories (
            name,
            icon
          ),
          author:profiles!articles_author_id_fkey (
            display_name,
            avatar_url
          )
        `)
        .eq("published", true)
        .order("published_at", { ascending: false })
        .limit(15);

      if (error) throw error;
      setArticles((data as Article[]) || []);
    } catch (error) {
      console.error("Error fetching default feed:", error);
      setArticles([]);
    } finally {
      setLoading(false);
    }
  };

  return {
    articles,
    loading,
    preferences,
    refresh: user ? fetchPersonalizedFeed : fetchDefaultFeed,
  };
};
