import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { TipTapBlockEditor } from "@/components/editor/TipTapBlockEditor";
import { Upload, Trash2, CheckCircle, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface ArticleVersion {
  id?: string;
  language_code: string;
  style: string;
  content_html: string;
  audio_url?: string;
  approved_by_cultural_partner?: boolean;
  moderation_status?: string;
}

interface ArticleVersionsEditorProps {
  articleId?: string;
  versions: ArticleVersion[];
  onVersionsChange: (versions: ArticleVersion[]) => void;
  userId?: string;
}

// Fonction de validation pour s'assurer que l'article peut être publié
export const validateArticleVersionsForPublish = (versions: ArticleVersion[]): { valid: boolean; errors: string[] } => {
  const errors: string[] = [];
  
  // Vérifier la version française standard
  const frStandard = versions.find(v => v.language_code === 'fr' && v.style === 'standard');
  
  if (!frStandard) {
    errors.push("La version française standard est obligatoire");
  } else {
    if (!frStandard.content_html || frStandard.content_html.trim() === '') {
      errors.push("Le contenu français standard est vide");
    }
    if (!frStandard.audio_url) {
      errors.push("L'audio français standard est requis");
    }
  }
  
  return {
    valid: errors.length === 0,
    errors,
  };
};

const languageNames: Record<string, string> = {
  fr: "Français",
  mo: "Mooré",
  ln: "Lingala",
  ewe: "Ewe",
  yo: "Yoruba",
  ha: "Haoussa",
};

const availableLanguages = [
  { code: 'fr', name: 'Français', required: true },
  { code: 'mo', name: 'Mooré', required: false },
  { code: 'ln', name: 'Lingala', required: false },
  { code: 'ewe', name: 'Ewe', required: false },
  { code: 'yo', name: 'Yoruba', required: false },
  { code: 'ha', name: 'Haoussa', required: false },
];

export const ArticleVersionsEditor = ({
  articleId,
  versions,
  onVersionsChange,
  userId,
}: ArticleVersionsEditorProps) => {
  const [uploadingAudio, setUploadingAudio] = useState<string | null>(null);

  const getVersion = (langCode: string, style: string): ArticleVersion | undefined => {
    return versions.find(v => v.language_code === langCode && v.style === style);
  };

  const updateVersion = (langCode: string, style: string, updates: Partial<ArticleVersion>) => {
    const existingIndex = versions.findIndex(
      v => v.language_code === langCode && v.style === style
    );

    if (existingIndex >= 0) {
      const newVersions = [...versions];
      newVersions[existingIndex] = { ...newVersions[existingIndex], ...updates };
      onVersionsChange(newVersions);
    } else {
      // Déterminer le statut de modération initial
      let moderationStatus: string;
      if (style === 'argot') {
        moderationStatus = 'pending'; // Argot nécessite validation admin
      } else if (langCode === 'fr' && style === 'standard') {
        moderationStatus = 'approved'; // Français standard est pré-approuvé
      } else {
        moderationStatus = 'pending_cultural'; // Langues traditionnelles nécessitent validation culturelle
      }

      onVersionsChange([
        ...versions,
        {
          language_code: langCode,
          style,
          content_html: '',
          moderation_status: moderationStatus,
          approved_by_cultural_partner: false,
          ...updates,
        },
      ]);
    }
  };

  const handleAudioUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    langCode: string,
    style: string
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      toast.error("Le fichier doit être un fichier audio");
      return;
    }

    const key = `${langCode}-${style}`;
    setUploadingAudio(key);

    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${userId}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('article-media')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('article-media')
        .getPublicUrl(filePath);

      updateVersion(langCode, style, { audio_url: data.publicUrl });
      toast.success("Audio téléchargé avec succès");
    } catch (error: any) {
      console.error("Erreur d'upload:", error);
      toast.error(`Erreur lors du téléchargement: ${error.message}`);
    } finally {
      setUploadingAudio(null);
    }
  };

  const removeAudio = (langCode: string, style: string) => {
    updateVersion(langCode, style, { audio_url: undefined });
    toast.success("Audio supprimé");
  };

  const standardFr = getVersion('fr', 'standard');
  const argotFr = getVersion('fr', 'argot');

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-md p-4">
        <h3 className="font-semibold text-blue-900 dark:text-blue-100 flex items-center gap-2 mb-2">
          <AlertCircle className="h-5 w-5" />
          Politique de publication
        </h3>
        <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1 list-disc list-inside">
          <li><strong>Français standard</strong> : Obligatoire (texte + audio)</li>
          <li><strong>Argot</strong> : Optionnel, nécessite validation par un modérateur</li>
          <li><strong>Langues traditionnelles</strong> : Optionnelles, nécessitent validation culturelle</li>
        </ul>
      </div>

      <Tabs defaultValue="fr-standard" className="w-full">
        <TabsList className="grid grid-cols-2 lg:grid-cols-3 gap-2">
          <TabsTrigger value="fr-standard" className="relative">
            Français Standard
            {standardFr?.content_html && standardFr?.audio_url && (
              <CheckCircle className="h-4 w-4 text-green-500 absolute -top-1 -right-1" />
            )}
          </TabsTrigger>
          <TabsTrigger value="fr-argot">
            Argot
            {argotFr?.moderation_status === 'pending' && (
              <Badge variant="outline" className="ml-2 text-xs">En attente</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="langues-traditionnelles">
            Langues traditionnelles
          </TabsTrigger>
        </TabsList>

        {/* Français Standard - OBLIGATOIRE */}
        <TabsContent value="fr-standard" className="space-y-4">
          <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-md p-3">
            <p className="text-sm text-yellow-800 dark:text-yellow-200">
              ⚠️ Cette version est <strong>obligatoire</strong>. Texte et audio requis pour publier.
            </p>
          </div>

          <div>
            <Label htmlFor="content-fr-standard">Contenu (HTML) *</Label>
            <TipTapBlockEditor
              content={standardFr?.content_html || ''}
              onChange={(html) => updateVersion('fr', 'standard', { content_html: html })}
            />
          </div>

          <div>
            <Label htmlFor="audio-fr-standard">Audio (MP3, WAV, etc.) *</Label>
            <div className="flex gap-2 items-center">
              <Input
                id="audio-fr-standard"
                type="file"
                accept="audio/*"
                onChange={(e) => handleAudioUpload(e, 'fr', 'standard')}
                disabled={uploadingAudio === 'fr-standard'}
                data-testid="input-audio-fr-standard"
              />
              {uploadingAudio === 'fr-standard' && (
                <Button disabled size="sm">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload...
                </Button>
              )}
              {standardFr?.audio_url && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeAudio('fr', 'standard')}
                  data-testid="button-remove-audio-fr-standard"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
            {standardFr?.audio_url && (
              <audio controls src={standardFr.audio_url} className="mt-2 w-full" />
            )}
          </div>
        </TabsContent>

        {/* Français Argot - OPTIONNEL */}
        <TabsContent value="fr-argot" className="space-y-4">
          <div className="bg-orange-50 dark:bg-orange-950 border border-orange-200 dark:border-orange-800 rounded-md p-3">
            <p className="text-sm text-orange-800 dark:text-orange-200">
              ℹ️ Version optionnelle. Sera soumise à validation par un modérateur avant publication.
            </p>
          </div>

          <div>
            <Label htmlFor="content-fr-argot">Contenu (HTML)</Label>
            <TipTapBlockEditor
              content={argotFr?.content_html || ''}
              onChange={(html) => updateVersion('fr', 'argot', { content_html: html })}
            />
          </div>

          <div>
            <Label htmlFor="audio-fr-argot">Audio (optionnel mais encouragé)</Label>
            <div className="flex gap-2 items-center">
              <Input
                id="audio-fr-argot"
                type="file"
                accept="audio/*"
                onChange={(e) => handleAudioUpload(e, 'fr', 'argot')}
                disabled={uploadingAudio === 'fr-argot'}
                data-testid="input-audio-fr-argot"
              />
              {uploadingAudio === 'fr-argot' && (
                <Button disabled size="sm">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload...
                </Button>
              )}
              {argotFr?.audio_url && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => removeAudio('fr', 'argot')}
                  data-testid="button-remove-audio-fr-argot"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
            {argotFr?.audio_url && (
              <audio controls src={argotFr.audio_url} className="mt-2 w-full" />
            )}
          </div>

          {argotFr?.moderation_status === 'pending' && (
            <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-md p-3">
              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                ⏳ Cette version est en attente de modération
              </p>
            </div>
          )}
        </TabsContent>

        {/* Langues Traditionnelles */}
        <TabsContent value="langues-traditionnelles" className="space-y-6">
          <div className="bg-purple-50 dark:bg-purple-950 border border-purple-200 dark:border-purple-800 rounded-md p-3">
            <p className="text-sm text-purple-800 dark:text-purple-200">
              🌍 Les langues traditionnelles nécessitent une <strong>validation culturelle</strong> par un locuteur natif ou un partenaire culturel.
            </p>
          </div>

          {availableLanguages
            .filter(lang => lang.code !== 'fr')
            .map(lang => {
              const version = getVersion(lang.code, 'standard');
              const key = `${lang.code}-standard`;
              
              return (
                <div key={lang.code} className="border rounded-md p-4 space-y-4">
                  <h4 className="font-semibold flex items-center gap-2">
                    {lang.name}
                    {version?.approved_by_cultural_partner && (
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Validé
                      </Badge>
                    )}
                  </h4>

                  <div>
                    <Label htmlFor={`content-${lang.code}`}>Contenu (HTML)</Label>
                    <TipTapBlockEditor
                      content={version?.content_html || ''}
                      onChange={(html) => updateVersion(lang.code, 'standard', { content_html: html })}
                    />
                  </div>

                  <div>
                    <Label htmlFor={`audio-${lang.code}`}>Audio</Label>
                    <div className="flex gap-2 items-center">
                      <Input
                        id={`audio-${lang.code}`}
                        type="file"
                        accept="audio/*"
                        onChange={(e) => handleAudioUpload(e, lang.code, 'standard')}
                        disabled={uploadingAudio === key}
                        data-testid={`input-audio-${lang.code}`}
                      />
                      {uploadingAudio === key && (
                        <Button disabled size="sm">
                          <Upload className="mr-2 h-4 w-4" />
                          Upload...
                        </Button>
                      )}
                      {version?.audio_url && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeAudio(lang.code, 'standard')}
                          data-testid={`button-remove-audio-${lang.code}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                    {version?.audio_url && (
                      <audio controls src={version.audio_url} className="mt-2 w-full" />
                    )}
                  </div>
                </div>
              );
            })}
        </TabsContent>
      </Tabs>
    </div>
  );
};
