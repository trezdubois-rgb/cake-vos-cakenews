import { useState, useEffect } from "react";
import { Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface AvailableVersion {
  language_code: string;
  style: string;
  has_audio: boolean;
}

interface LanguageStyleSelectorProps {
  articleId: string;
  currentLanguage: string;
  currentStyle: string;
  onVersionChange: (language: string, style: string) => void;
}

const languageNames: Record<string, string> = {
  fr: "Français",
  mo: "Mooré",
  ln: "Lingala",
  ewe: "Ewe",
  yo: "Yoruba",
  ha: "Haoussa",
};

const styleNames: Record<string, string> = {
  standard: "Standard",
  argot: "Argot",
};

export const LanguageStyleSelector = ({
  articleId,
  currentLanguage,
  currentStyle,
  onVersionChange,
}: LanguageStyleSelectorProps) => {
  const [open, setOpen] = useState(false);
  const [availableVersions, setAvailableVersions] = useState<AvailableVersion[]>([]);
  const [selectedLanguage, setSelectedLanguage] = useState(currentLanguage);
  const [selectedStyle, setSelectedStyle] = useState(currentStyle);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      fetchAvailableVersions();
    }
  }, [open, articleId]);

  const fetchAvailableVersions = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('article_versions')
        .select('language_code, style, audio_url')
        .eq('article_id', articleId)
        .eq('moderation_status', 'approved');

      if (error) throw error;

      const versions: AvailableVersion[] = (data || []).map(v => ({
        language_code: v.language_code,
        style: v.style,
        has_audio: !!(v.audio_url && v.audio_url !== ''),
      }));

      setAvailableVersions(versions);
    } catch (error) {
      console.error('Error fetching versions:', error);
      toast.error("Erreur lors du chargement des versions disponibles");
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async () => {
    if (selectedLanguage === currentLanguage && selectedStyle === currentStyle) {
      setOpen(false);
      return;
    }

    const versionExists = availableVersions.some(
      v => v.language_code === selectedLanguage && v.style === selectedStyle
    );

    if (!versionExists) {
      toast.info("Cette version n'est pas encore disponible. Vous lisez la version standard.");
      setSelectedLanguage('fr');
      setSelectedStyle('standard');
      return;
    }

    onVersionChange(selectedLanguage, selectedStyle);
    
    // Sauvegarder les préférences utilisateur dans les préférences JSON
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('preferences')
        .eq('id', user.id)
        .single();

      const currentPrefs = (profile?.preferences as any) || {};
      
      await supabase
        .from('profiles')
        .update({
          preferences: {
            ...currentPrefs,
            preferred_language: selectedLanguage,
            preferred_style: selectedStyle,
          }
        })
        .eq('id', user.id);
    }

    toast.success("Version changée avec succès");
    setOpen(false);
  };

  const uniqueLanguages = Array.from(
    new Set(availableVersions.map(v => v.language_code))
  );

  const availableStyles = availableVersions
    .filter(v => v.language_code === selectedLanguage)
    .map(v => v.style);

  return (
    <>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setOpen(true)}
        className="flex flex-col items-center gap-1 text-xs text-destructive-foreground hover:bg-destructive-foreground/10"
        data-testid="button-language-selector"
      >
        <Languages size={24} />
        <span className="font-medium">Langue</span>
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md" data-testid="dialog-language-selector">
          <DialogHeader>
            <DialogTitle>Choisir une version</DialogTitle>
            <DialogDescription>
              Sélectionnez la langue et le style de votre choix. Votre préférence sera mémorisée.
            </DialogDescription>
          </DialogHeader>

          {loading ? (
            <div className="py-8 text-center text-muted-foreground">
              Chargement des versions disponibles...
            </div>
          ) : (
            <div className="space-y-6 py-4">
              <div className="space-y-3">
                <Label className="text-base font-semibold">Langue</Label>
                <RadioGroup
                  value={selectedLanguage}
                  onValueChange={setSelectedLanguage}
                  className="grid gap-2"
                >
                  {uniqueLanguages.map((lang) => (
                    <div key={lang} className="flex items-center space-x-2">
                      <RadioGroupItem value={lang} id={`lang-${lang}`} data-testid={`radio-language-${lang}`} />
                      <Label
                        htmlFor={`lang-${lang}`}
                        className="flex-1 cursor-pointer"
                      >
                        {languageNames[lang] || lang}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <div className="space-y-3">
                <Label className="text-base font-semibold">Style</Label>
                <RadioGroup
                  value={selectedStyle}
                  onValueChange={setSelectedStyle}
                  className="grid gap-2"
                >
                  {availableStyles.map((style) => (
                    <div key={style} className="flex items-center space-x-2">
                      <RadioGroupItem value={style} id={`style-${style}`} data-testid={`radio-style-${style}`} />
                      <Label
                        htmlFor={`style-${style}`}
                        className="flex-1 cursor-pointer"
                      >
                        {styleNames[style] || style}
                        {style === 'argot' && (
                          <span className="ml-2 text-xs text-muted-foreground">
                            (Français urbain)
                          </span>
                        )}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
                {availableStyles.length === 0 && (
                  <p className="text-sm text-muted-foreground">
                    Aucun style disponible pour cette langue
                  </p>
                )}
              </div>

              <div className="flex gap-2 justify-end">
                <Button
                  variant="outline"
                  onClick={() => setOpen(false)}
                  data-testid="button-cancel"
                >
                  Annuler
                </Button>
                <Button
                  onClick={handleApply}
                  data-testid="button-apply"
                >
                  Appliquer
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};
