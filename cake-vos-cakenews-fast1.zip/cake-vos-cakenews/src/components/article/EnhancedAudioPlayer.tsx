import { useState, useRef, useEffect } from "react";
import { Headphones, Play, Pause, Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface EnhancedAudioPlayerProps {
  audioUrl?: string;
  title: string;
}

export const EnhancedAudioPlayer = ({ audioUrl, title }: EnhancedAudioPlayerProps) => {
  const [open, setOpen] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const updateTime = () => setCurrentTime(audio.currentTime);
    const updateDuration = () => setDuration(audio.duration);
    const handleEnded = () => setIsPlaying(false);

    audio.addEventListener('timeupdate', updateTime);
    audio.addEventListener('loadedmetadata', updateDuration);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', updateTime);
      audio.removeEventListener('loadedmetadata', updateDuration);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackRate;
    }
  }, [playbackRate]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  const togglePlay = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (value: number[]) => {
    if (!audioRef.current) return;
    audioRef.current.currentTime = value[0];
    setCurrentTime(value[0]);
  };

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0]);
    if (value[0] > 0) setIsMuted(false);
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  if (!audioUrl) return null;

  return (
    <>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setOpen(true)}
        className="flex flex-col items-center gap-1 text-xs text-destructive-foreground hover:bg-destructive-foreground/10"
        data-testid="button-audio-player"
      >
        <Headphones size={24} />
        <span className="font-medium">Écouter</span>
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md" data-testid="dialog-audio-player">
          <DialogHeader>
            <DialogTitle>Lecture audio</DialogTitle>
            <DialogDescription>{title}</DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <audio ref={audioRef} src={audioUrl} preload="metadata" />

            {/* Play/Pause Button */}
            <div className="flex justify-center">
              <Button
                size="lg"
                variant="outline"
                onClick={togglePlay}
                className="h-16 w-16 rounded-full"
                data-testid="button-play-pause"
              >
                {isPlaying ? <Pause size={32} /> : <Play size={32} />}
              </Button>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <Slider
                value={[currentTime]}
                min={0}
                max={duration || 100}
                step={1}
                onValueChange={handleSeek}
                className="cursor-pointer"
                data-testid="slider-progress"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Volume Control */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Volume</Label>
              <div className="flex items-center gap-3">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={toggleMute}
                  className="h-8 w-8"
                  data-testid="button-mute"
                >
                  {isMuted || volume === 0 ? <VolumeX size={18} /> : <Volume2 size={18} />}
                </Button>
                <Slider
                  value={[isMuted ? 0 : volume]}
                  min={0}
                  max={1}
                  step={0.01}
                  onValueChange={handleVolumeChange}
                  className="flex-1"
                  data-testid="slider-volume"
                />
              </div>
            </div>

            {/* Playback Speed */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Vitesse de lecture</Label>
              <RadioGroup
                value={playbackRate.toString()}
                onValueChange={(value) => setPlaybackRate(parseFloat(value))}
                className="flex gap-2"
              >
                {[0.75, 1, 1.25, 1.5].map((rate) => (
                  <div key={rate} className="flex items-center space-x-2">
                    <RadioGroupItem value={rate.toString()} id={`rate-${rate}`} data-testid={`radio-speed-${rate}`} />
                    <Label
                      htmlFor={`rate-${rate}`}
                      className="cursor-pointer text-sm"
                    >
                      {rate}x
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
