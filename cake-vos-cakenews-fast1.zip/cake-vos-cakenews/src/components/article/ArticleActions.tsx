import { useState, useEffect } from "react";
import { Heart, MessageCircle, Share2, Bookmark, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ReportMenu } from "./ReportMenu";
import { CommentDialog } from "./CommentDialog";
import { LanguageStyleSelector } from "./LanguageStyleSelector";
import { EnhancedAudioPlayer } from "./EnhancedAudioPlayer";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

interface CommentReaction {
  emoji: string;
  count: number;
  userReacted: boolean;
}

interface Comment {
  id: string;
  content: string;
  author: {
    id: string;
    name: string;
    avatar?: string;
  };
  created_at: string;
  like_count: number;
  reactions?: CommentReaction[];
  isHidden?: boolean;
  replies?: Comment[];
}

interface ArticleActionsProps {
  articleId: string;
  authorId: string;
  authorName: string;
  title: string;
  category: string;
  tags: string[];
  initialLikeCount: number;
  publishedAt?: string;
  updatedAt?: string;
  audioUrl?: string;
  currentLanguage?: string;
  currentStyle?: string;
  onVersionChange?: (language: string, style: string) => void;
}

export const ArticleActions = ({
  articleId,
  authorId,
  authorName,
  title,
  category,
  tags,
  initialLikeCount,
  publishedAt,
  updatedAt,
  audioUrl,
  currentLanguage = 'fr',
  currentStyle = 'standard',
  onVersionChange,
}: ArticleActionsProps) => {
  const [liked, setLiked] = useState(false);
  const [favorited, setFavorited] = useState(false);
  const [likeCount, setLikeCount] = useState(initialLikeCount);
  const [loading, setLoading] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);

  useEffect(() => {
    checkIfLiked();
    checkIfFavorited();
    fetchComments();
  }, [articleId]);

  const checkIfFavorited = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    try {
      const { data } = await supabase
        .from("user_interactions")
        .select("favorited")
        .eq("article_id", articleId)
        .eq("user_id", user.id)
        .maybeSingle();

      if (data) {
        setFavorited(data.favorited || false);
      }
    } catch (error) {
      console.error("Error checking favorite status:", error);
    }
  };

  const handleFavorite = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      toast.error("Connectez-vous pour sauvegarder des articles");
      return;
    }

    setLoading(true);
    try {
      const newFavorited = !favorited;
      
      const { data: existingInteraction } = await supabase
        .from("user_interactions")
        .select("id")
        .eq("article_id", articleId)
        .eq("user_id", user.id)
        .maybeSingle();

      if (existingInteraction) {
        await supabase
          .from("user_interactions")
          .update({ favorited: newFavorited })
          .eq("id", existingInteraction.id);
      } else {
        await supabase
          .from("user_interactions")
          .insert({
            article_id: articleId,
            user_id: user.id,
            favorited: newFavorited,
          });
      }

      setFavorited(newFavorited);
      toast.success(newFavorited ? "Article ajouté aux favoris" : "Article retiré des favoris");
    } catch (error: any) {
      toast.error("Erreur lors de la sauvegarde");
      console.error("Error favoriting:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchComments = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    
    const { data, error } = await supabase
      .from('comments')
      .select(`
        id,
        content,
        created_at,
        like_count,
        user_id,
        parent_id,
        profiles (
          id,
          display_name,
          avatar_url
        )
      `)
      .eq('article_id', articleId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching comments:', error);
      return;
    }

    // Fetch reactions for all comments
    const { data: reactionsData } = await supabase
      .from('comment_reactions')
      .select('comment_id, emoji, user_id')
      .in('comment_id', data?.map(c => c.id) || []);

    // Fetch hidden comments for current user
    const { data: hiddenData } = user ? await supabase
      .from('hidden_comments')
      .select('comment_id')
      .eq('user_id', user.id)
      .in('comment_id', data?.map(c => c.id) || []) : { data: [] };

    const hiddenCommentIds = new Set(hiddenData?.map(h => h.comment_id) || []);

    // Group reactions by comment
    const reactionsByComment = new Map<string, Map<string, { count: number; userReacted: boolean }>>();
    reactionsData?.forEach((reaction: any) => {
      if (!reactionsByComment.has(reaction.comment_id)) {
        reactionsByComment.set(reaction.comment_id, new Map());
      }
      const emojiMap = reactionsByComment.get(reaction.comment_id)!;
      if (!emojiMap.has(reaction.emoji)) {
        emojiMap.set(reaction.emoji, { count: 0, userReacted: false });
      }
      const emojiData = emojiMap.get(reaction.emoji)!;
      emojiData.count++;
      if (user && reaction.user_id === user.id) {
        emojiData.userReacted = true;
      }
    });

    // Format comments with nested replies
    const formattedComments: Comment[] = [];
    const commentMap = new Map<string, Comment>();

    data?.forEach((comment: any) => {
      const reactions = reactionsByComment.get(comment.id);
      const formattedComment: Comment = {
        id: comment.id,
        content: comment.content,
        author: {
          id: comment.profiles.id,
          name: comment.profiles.display_name || 'Utilisateur',
          avatar: comment.profiles.avatar_url,
        },
        created_at: comment.created_at,
        like_count: comment.like_count || 0,
        reactions: reactions ? Array.from(reactions.entries()).map(([emoji, data]) => ({
          emoji,
          count: data.count,
          userReacted: data.userReacted,
        })) : [],
        isHidden: hiddenCommentIds.has(comment.id),
        replies: [],
      };
      commentMap.set(comment.id, formattedComment);

      if (!comment.parent_id) {
        formattedComments.push(formattedComment);
      }
    });

    // Link replies to parents
    data?.forEach((comment: any) => {
      if (comment.parent_id) {
        const parent = commentMap.get(comment.parent_id);
        const child = commentMap.get(comment.id);
        if (parent && child) {
          parent.replies!.push(child);
        }
      }
    });

    setComments(formattedComments);
  };

  const checkIfLiked = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    try {
      const { data } = await supabase
        .from("user_interactions")
        .select("liked")
        .eq("article_id", articleId)
        .eq("user_id", user.id)
        .maybeSingle();

      if (data) {
        setLiked(data.liked || false);
      }
    } catch (error) {
      console.error("Error checking like status:", error);
    }
  };

  const handleLike = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      toast.error("Connectez-vous pour interagir avec les articles");
      return;
    }

    setLoading(true);
    try {
      const newLiked = !liked;
      
      // Update or insert user interaction
      const { data: existingInteraction } = await supabase
        .from("user_interactions")
        .select("id")
        .eq("article_id", articleId)
        .eq("user_id", user.id)
        .maybeSingle();

      if (existingInteraction) {
        await supabase
          .from("user_interactions")
          .update({ liked: newLiked })
          .eq("id", existingInteraction.id);
      } else {
        await supabase
          .from("user_interactions")
          .insert({
            article_id: articleId,
            user_id: user.id,
            liked: newLiked,
          });
      }

      // Update article like count
      const newLikeCount = newLiked ? likeCount + 1 : likeCount - 1;
      await supabase
        .from("articles")
        .update({ like_count: newLikeCount })
        .eq("id", articleId);

      setLiked(newLiked);
      setLikeCount(newLikeCount);
    } catch (error: any) {
      toast.error("Erreur lors du like");
      console.error("Error liking:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleShare = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      toast.error("Connectez-vous pour partager des articles");
      return;
    }
    
    const url = `${window.location.origin}/article/${articleId}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Article",
          url: url,
        });
      } catch (err) {
        // User cancelled
      }
    } else {
      await navigator.clipboard.writeText(url);
      toast.success("Lien copié dans le presse-papier");
    }
  };

  const handleReportContent = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      toast.error("Connectez-vous pour signaler du contenu");
      return;
    }
    
    toast.info("Contenu signalé. Merci pour votre vigilance.");
  };

  const handleSendFeedback = () => {
    toast.info("Merci pour votre avis !");
  };

  const handleHideArticle = () => {
    toast.info("Article masqué");
  };

  const handleHideAuthor = () => {
    toast.info(`Tous les articles de ${authorName} seront masqués`);
  };

  const handleHideCategory = () => {
    toast.info(`Vous ne verrez plus la catégorie "${category}"`);
  };

  const handleHideTag = (tag: string) => {
    toast.info(`Tag #${tag} masqué`);
  };

  const handleAddComment = async (content: string, parentId?: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error("Vous devez être connecté pour commenter");
      return;
    }

    const { error } = await supabase.from('comments').insert({
      article_id: articleId,
      user_id: user.id,
      content,
      parent_id: parentId,
    });

    if (error) {
      console.error('Error adding comment:', error);
      throw error;
    }

    await fetchComments();
  };

  const handleLikeComment = async (commentId: string, isLiked: boolean) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    if (isLiked) {
      const { error } = await supabase.from('comment_likes').insert({
        comment_id: commentId,
        user_id: user.id,
      });

      if (!error) {
        await supabase.rpc('increment_comment_likes', { comment_id: commentId });
      }
    } else {
      await supabase
        .from('comment_likes')
        .delete()
        .eq('comment_id', commentId)
        .eq('user_id', user.id);

      await supabase.rpc('decrement_comment_likes', { comment_id: commentId });
    }

    await fetchComments();
  };

  return (
    <>
      {/* Barre d'actions enrichie - Rouge (au-dessus de la navigation) */}
      <div className="fixed bottom-16 left-0 right-0 bg-destructive/95 backdrop-blur-sm border-t border-destructive shadow-lg z-40">
        <div className="flex items-center justify-around px-2 py-2 max-w-screen-xl mx-auto overflow-x-auto">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLike}
            disabled={loading}
            className={`flex flex-col items-center gap-1 text-xs text-destructive-foreground hover:bg-destructive-foreground/10 min-w-[60px] ${liked ? 'opacity-100' : 'opacity-90'}`}
            data-testid="button-like"
          >
            <Heart
              size={20}
              className={liked ? 'fill-destructive-foreground' : ''}
            />
            <span className="font-medium text-[10px]">{likeCount > 0 ? likeCount : 'J\'aime'}</span>
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowComments(true)}
            className="flex flex-col items-center gap-1 text-xs text-destructive-foreground hover:bg-destructive-foreground/10 min-w-[60px]"
            data-testid="button-comment"
          >
            <MessageCircle size={20} />
            <span className="font-medium text-[10px]">Commenter</span>
          </Button>

          <ReportMenu
            articleId={articleId}
            authorId={authorId}
            authorName={authorName}
            category={category}
            tags={tags}
            onReportContent={handleReportContent}
            onSendFeedback={handleSendFeedback}
            onHideArticle={handleHideArticle}
            onHideAuthor={handleHideAuthor}
            onHideCategory={handleHideCategory}
            onHideTag={handleHideTag}
          />

          <Button
            variant="ghost"
            size="sm"
            onClick={handleShare}
            className="flex flex-col items-center gap-1 text-xs text-destructive-foreground hover:bg-destructive-foreground/10 min-w-[60px]"
            data-testid="button-share"
          >
            <Share2 size={20} />
            <span className="font-medium text-[10px]">Partager</span>
          </Button>

          {audioUrl && (
            <EnhancedAudioPlayer audioUrl={audioUrl} title={title} />
          )}

          <LanguageStyleSelector
            articleId={articleId}
            currentLanguage={currentLanguage}
            currentStyle={currentStyle}
            onVersionChange={(lang, style) => {
              if (onVersionChange) {
                onVersionChange(lang, style);
              }
            }}
          />

          <Button
            variant="ghost"
            size="sm"
            onClick={handleFavorite}
            disabled={loading}
            className={`flex flex-col items-center gap-1 text-xs text-destructive-foreground hover:bg-destructive-foreground/10 min-w-[60px] ${favorited ? 'opacity-100' : 'opacity-90'}`}
            data-testid="button-favorite"
          >
            <Bookmark
              size={20}
              className={favorited ? 'fill-destructive-foreground' : ''}
            />
            <span className="font-medium text-[10px]">Sauvegarder</span>
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowHistory(true)}
            className="flex flex-col items-center gap-1 text-xs text-destructive-foreground hover:bg-destructive-foreground/10 min-w-[60px]"
            data-testid="button-history"
          >
            <Clock size={20} />
            <span className="font-medium text-[10px]">Historique</span>
          </Button>
        </div>
      </div>

      {/* Dialog Historique */}
      {showHistory && (
        <Dialog open={showHistory} onOpenChange={setShowHistory}>
          <DialogContent className="sm:max-w-md" data-testid="dialog-history">
            <DialogHeader>
              <DialogTitle>Historique de l'article</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {publishedAt && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Publié le:</span>
                  <span className="text-sm font-medium">
                    {format(new Date(publishedAt), 'PPP', { locale: fr })}
                  </span>
                </div>
              )}
              {updatedAt && publishedAt && updatedAt !== publishedAt && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Dernière modification:</span>
                  <span className="text-sm font-medium">
                    {format(new Date(updatedAt), 'PPP', { locale: fr })}
                  </span>
                </div>
              )}
              {!publishedAt && (
                <p className="text-sm text-muted-foreground text-center">
                  Aucune information d'historique disponible
                </p>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}

      <CommentDialog
        open={showComments}
        onOpenChange={setShowComments}
        articleId={articleId}
        comments={comments}
        onAddComment={handleAddComment}
        onLikeComment={handleLikeComment}
      />
    </>
  );
};